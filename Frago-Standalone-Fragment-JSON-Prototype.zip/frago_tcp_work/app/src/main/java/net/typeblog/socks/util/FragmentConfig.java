package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.InetAddress;
import java.util.Locale;

/** Parses the user's Xray-style JSON profile for the limited native TCP Fragment engine. */
public final class FragmentConfig {
    public final int socksPort, minLength, maxLength, minInterval, maxInterval;
    public final String packets, dohUrl;
    public final boolean directIranDomains, directPrivateIps, fragmentTcp;

    private FragmentConfig(int p, int a, int b, int c, int d, String pkt, String doh,
                           boolean ir, boolean privateIp, boolean tcp) {
        socksPort=p; minLength=a; maxLength=b; minInterval=c; maxInterval=d;
        packets=pkt; dohUrl=doh; directIranDomains=ir; directPrivateIps=privateIp; fragmentTcp=tcp;
    }

    public static FragmentConfig parse(String raw) throws Exception {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("فایل JSON خالی است");
        JSONObject root = new JSONObject(raw);
        JSONArray ins = root.optJSONArray("inbounds");
        if (ins == null || ins.length() == 0) throw new IllegalArgumentException("بخش inbounds در JSON پیدا نشد");
        int port = 10808;
        for (int i=0;i<ins.length();i++) {
            JSONObject in=ins.optJSONObject(i);
            if (in != null && "socks".equalsIgnoreCase(in.optString("protocol"))) {
                int candidate=in.optInt("port",10808);
                if(candidate>0 && candidate<65536) port=candidate;
                break;
            }
        }
        int min=10,max=400,imin=1,imax=30;
        String packets="tlshello";
        JSONArray outs=root.optJSONArray("outbounds");
        if(outs!=null) for(int i=0;i<outs.length();i++) {
            JSONObject ob=outs.optJSONObject(i); if(ob==null) continue;
            if (!"fragment-out".equals(ob.optString("tag"))) continue;
            JSONObject settings=ob.optJSONObject("settings");
            JSONObject fragment=settings==null?null:settings.optJSONObject("fragment");
            if(fragment!=null) {
                packets=fragment.optString("packets", "tlshello").toLowerCase(Locale.ROOT);
                int[] length=parseRange(fragment.optString("length", "10-400"),10,400);
                int[] interval=parseRange(fragment.optString("interval", "1-30"),1,30);
                min=length[0]; max=length[1]; imin=interval[0]; imax=interval[1];
            }
            break;
        }
        if (!"tlshello".equals(packets)) throw new IllegalArgumentException("موتور فعلی فقط packets=tlshello را پشتیبانی می‌کند");
        min=Math.max(1,Math.min(min,4096)); max=Math.max(min,Math.min(max,8192));
        imin=Math.max(0,Math.min(imin,1000)); imax=Math.max(imin,Math.min(imax,2000));

        String doh="";
        JSONObject dns=root.optJSONObject("dns");
        if(dns!=null) {
            JSONArray servers=dns.optJSONArray("servers");
            if(servers!=null && servers.length()>0) doh=servers.optString(0, "");
        }
        // The supplied routing rules are recognized for TCP destination selection.
        boolean ir=false, privateIp=false, tcp=false;
        JSONObject routing=root.optJSONObject("routing");
        JSONArray rules=routing==null?null:routing.optJSONArray("rules");
        if(rules!=null) for(int i=0;i<rules.length();i++) {
            JSONObject rule=rules.optJSONObject(i); if(rule==null) continue;
            String tag=rule.optString("outboundTag");
            JSONArray domains=rule.optJSONArray("domain");
            if("direct".equals(tag) && domains!=null) {
                for(int j=0;j<domains.length();j++) if(domains.optString(j).contains("\\.ir")) ir=true;
            }
            JSONArray ips=rule.optJSONArray("ip");
            if("direct".equals(tag) && ips!=null && ips.length()>0) privateIp=true;
            if("fragment-out".equals(tag) && "tcp".equalsIgnoreCase(rule.optString("network"))) tcp=true;
        }
        return new FragmentConfig(port,min,max,imin,imax,packets,doh,ir,privateIp,tcp);
    }

    private static int[] parseRange(String value, int fallbackMin, int fallbackMax) {
        try {
            String[] parts=value.trim().split("-");
            if(parts.length==1) { int n=Integer.parseInt(parts[0].trim()); return new int[]{n,n}; }
            if(parts.length==2) {
                int a=Integer.parseInt(parts[0].trim()), b=Integer.parseInt(parts[1].trim());
                return new int[]{Math.min(a,b),Math.max(a,b)};
            }
        } catch(Exception ignored) { }
        return new int[]{fallbackMin,fallbackMax};
    }

    /** True only for TCP destinations selected by the supplied routing policy. */
    public boolean shouldFragmentHost(String host) {
        if (!fragmentTcp) return false;
        if (host == null) return true;
        String h=host.trim().toLowerCase(Locale.ROOT);
        if (directIranDomains && (h.equals("ir") || h.endsWith(".ir"))) return false;
        if (directPrivateIps && isPrivateOrLoopback(h)) return false;
        return true;
    }

    private static boolean isPrivateOrLoopback(String host) {
        try {
            // Do not resolve arbitrary hostnames here: that could leak DNS outside the VPN.
            if (!(host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}") || host.indexOf(':') >= 0)) return false;
            byte[] a=InetAddress.getByName(host).getAddress();
            if(a.length==4) {
                int x=a[0]&255, y=a[1]&255;
                return x==10 || x==127 || (x==172 && y>=16 && y<=31) || (x==192 && y==168);
            }
            return (a[0]&0xfe)==0xfc || InetAddress.getByAddress(a).isLoopbackAddress();
        } catch(Exception e) { return false; }
    }
}
