# Frago — standalone TCP Fragment prototype

This source removes the Xray and sing-box runtimes. It uses Android `VpnService`, the bundled ARM64 tun2socks/pdnsd libraries, and a Java SOCKS5 CONNECT bridge. The JSON input format remains Xray-style.

The parser understands the supplied `fragment-out` values (`packets=tlshello`, `length`, and `interval`) and applies the `.ir` direct exception for TCP domains plus literal private/loopback IP exceptions. System dark/light mode support is retained.

**Important:** this is not a complete Xray replacement. SOCKS5 UDP ASSOCIATE, the configured DoH endpoint, full IP routing after DNS resolution, blackhole, sniffing, and other Xray semantics are not implemented. Java socket write splitting is best-effort and cannot guarantee separate TCP segments. See `STATUS_FA.txt` before building or using it.

The prebuilt native libraries are ARM64 only. Build with Android Gradle Plugin/SDK compatible with the project.
