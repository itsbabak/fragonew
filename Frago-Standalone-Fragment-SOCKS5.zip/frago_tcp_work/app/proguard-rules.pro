# JNI methods are looked up by native symbol names; never obfuscate this bridge.
-keep class net.typeblog.socks.System { *; }

# Keep native method names in case they are referenced from JNI.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
