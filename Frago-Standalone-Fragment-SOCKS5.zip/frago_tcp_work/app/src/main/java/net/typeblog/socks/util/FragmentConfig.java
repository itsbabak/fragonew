package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.InetAddress;
import java.util.Locale;

/** Settings for Frago's standalone TCP Fragment + local SOCKS5 engine. */
public final class FragmentConfig {
    public static final int LOCAL_SOCKS_PORT = 10808;
    private static final String DEFAULT_DNS = "8.8.8.8";

    public final int socksPort;
    public final int minLength;
    public final int maxLength;
    public final int minInterval;
    public final int maxInterval;
    public final int dnsPort;
    public final String dnsServer;
    public final boolean fragmentTcp;
    public final boolean directIranDomains;
    public final boolean directPrivateIps;

    private FragmentConfig(int min, int max, int minDelay, int maxDelay,
                           int resolverPort, String resolver,
                           boolean enabled, boolean iranDirect, boolean privateDirect) {
        socksPort = LOCAL_SOCKS_PORT;
        minLength = min;
        maxLength = max;
        minInterval = minDelay;
        maxInterval = maxDelay;
        dnsPort = resolverPort;
        dnsServer = resolver;
        fragmentTcp = enabled;
        directIranDomains = iranDirect;
        directPrivateIps = privateDirect;
    }

    /**
     * Preferred Frago JSON format:
     * {"fragment":{"enabled":true,"packets":"tlshello","length":"10-400","interval":"1-30"},
     *  "dns":{"server":"8.8.8.8","port":53},
     *  "routing":{"skipIranDomains":false,"skipPrivateIps":false}}
     *
     * For migration only, the previous profile layout is also read. No external proxy core is loaded.
     */
    public static FragmentConfig parse(String raw) throws Exception {
        JSONObject root = (raw == null || raw.trim().isEmpty())
                ? new JSONObject() : new JSONObject(raw);

        JSONObject fragment = root.optJSONObject("fragment");
        if (fragment == null) fragment = findLegacyFragment(root);

        boolean enabled = fragment == null || fragment.optBoolean("enabled", true);
        String packets = fragment == null
                ? "tlshello" : fragment.optString("packets", "tlshello").toLowerCase(Locale.ROOT);
        if (enabled && !"tlshello".equals(packets)) {
            throw new IllegalArgumentException("موتور Frago فقط packets=tlshello را پشتیبانی می‌کند");
        }

        int min = 10, max = 400, minDelay = 1, maxDelay = 30;
        if (fragment != null) {
            int[] length = parseRange(fragment.optString("length", "10-400"), 10, 400);
            int[] interval = parseRange(fragment.optString("interval", "1-30"), 1, 30);
            min = length[0];
            max = length[1];
            minDelay = interval[0];
            maxDelay = interval[1];
        }
        min = clamp(min, 1, 4096);
        max = clamp(max, min, 8192);
        minDelay = clamp(minDelay, 0, 1000);
        maxDelay = clamp(maxDelay, minDelay, 2000);

        String dnsServer = DEFAULT_DNS;
        int dnsPort = 53;
        JSONObject dns = root.optJSONObject("dns");
        if (dns != null) {
            String candidate = dns.optString("server", "").trim();
            if (candidate.isEmpty()) {
                JSONArray servers = dns.optJSONArray("servers");
                if (servers != null && servers.length() > 0) {
                    candidate = servers.optString(0, "").trim();
                }
            }
            // pdnsd accepts a plain DNS server here, not an HTTPS DoH URL.
            if (isPlainDnsServer(candidate)) dnsServer = candidate;
            dnsPort = clamp(dns.optInt("port", 53), 1, 65535);
        }

        boolean skipIran = false;
        boolean skipPrivate = false;
        JSONObject routing = root.optJSONObject("routing");
        if (routing != null) {
            skipIran = routing.optBoolean("skipIranDomains", false);
            skipPrivate = routing.optBoolean("skipPrivateIps", false);
            // Compatibility with the former routing-rule layout.
            JSONArray rules = routing.optJSONArray("rules");
            if (rules != null) {
                for (int i = 0; i < rules.length(); i++) {
                    JSONObject rule = rules.optJSONObject(i);
                    if (rule == null || !"direct".equals(rule.optString("outboundTag"))) continue;
                    JSONArray domains = rule.optJSONArray("domain");
                    if (domains != null) {
                        for (int j = 0; j < domains.length(); j++) {
                            String value = domains.optString(j, "").toLowerCase(Locale.ROOT);
                            if (value.contains("\\.ir") || value.endsWith(".ir")) skipIran = true;
                        }
                    }
                    JSONArray ips = rule.optJSONArray("ip");
                    if (ips != null && ips.length() > 0) skipPrivate = true;
                }
            }
        }

        return new FragmentConfig(min, max, minDelay, maxDelay,
                dnsPort, dnsServer, enabled, skipIran, skipPrivate);
    }

    private static JSONObject findLegacyFragment(JSONObject root) {
        JSONArray outbounds = root.optJSONArray("outbounds");
        if (outbounds == null) return null;
        for (int i = 0; i < outbounds.length(); i++) {
            JSONObject outbound = outbounds.optJSONObject(i);
            if (outbound == null || !"fragment-out".equals(outbound.optString("tag"))) continue;
            JSONObject settings = outbound.optJSONObject("settings");
            return settings == null ? null : settings.optJSONObject("fragment");
        }
        return null;
    }

    private static boolean isPlainDnsServer(String value) {
        if (value == null || value.isEmpty() || value.contains("://") || value.contains("/")) return false;
        // Do not send hostnames through a resolver that may itself depend on the VPN tunnel.
        if (value.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) {
            String[] octets = value.split("\\.");
            for (String octet : octets) {
                try {
                    int number = Integer.parseInt(octet);
                    if (number < 0 || number > 255) return false;
                } catch (NumberFormatException e) {
                    return false;
                }
            }
            return true;
        }
        return value.indexOf(':') >= 0 && value.matches("[0-9a-fA-F:%.]+")
                && value.contains(":");
    }

    private static int[] parseRange(String value, int fallbackMin, int fallbackMax) {
        try {
            String[] parts = value.trim().split("-");
            if (parts.length == 1) {
                int number = Integer.parseInt(parts[0].trim());
                return new int[]{number, number};
            }
            if (parts.length == 2) {
                int first = Integer.parseInt(parts[0].trim());
                int second = Integer.parseInt(parts[1].trim());
                return new int[]{Math.min(first, second), Math.max(first, second)};
            }
        } catch (Exception ignored) { }
        return new int[]{fallbackMin, fallbackMax};
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    /** Applies Fragment except for destinations explicitly excluded in the profile. */
    public boolean shouldFragmentHost(String host) {
        if (!fragmentTcp) return false;
        if (host == null) return true;
        String normalized = host.trim().toLowerCase(Locale.ROOT);
        if (directIranDomains && (normalized.equals("ir") || normalized.endsWith(".ir"))) return false;
        return !directPrivateIps || !isPrivateOrLoopback(normalized);
    }

    private static boolean isPrivateOrLoopback(String host) {
        try {
            if (!(host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}") || host.indexOf(':') >= 0)) return false;
            byte[] address = InetAddress.getByName(host).getAddress();
            if (address.length == 4) {
                int first = address[0] & 255;
                int second = address[1] & 255;
                return first == 10 || first == 127
                        || (first == 172 && second >= 16 && second <= 31)
                        || (first == 192 && second == 168);
            }
            return (address[0] & 0xfe) == 0xfc || InetAddress.getByAddress(address).isLoopbackAddress();
        } catch (Exception ignored) {
            return false;
        }
    }
}
