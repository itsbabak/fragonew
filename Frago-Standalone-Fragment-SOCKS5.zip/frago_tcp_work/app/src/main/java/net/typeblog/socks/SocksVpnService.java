package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;

import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.FragmentConfig;

import java.util.Locale;
import java.util.Objects;

import static net.typeblog.socks.util.Constants.*;
import static net.typeblog.socks.BuildConfig.DEBUG;

/** VPN service for Frago's standalone SOCKS5 + TCP Fragment engine. */
public class SocksVpnService extends VpnService {
    private static final String TAG = "FragoVPN";

    private final IBinder binder = new VpnBinder();
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean running;
    private volatile boolean stopping;
    private volatile FragmentSocks5Engine socksServer;

    private final class VpnBinder extends IVpnService.Stub {
        @Override public boolean isRunning() { return running; }
        @Override public void stop() { stopMe(); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (running || socksServer != null) return START_STICKY;
        stopping = false;

        final String name = intent.getStringExtra(INTENT_NAME);
        final boolean perApp = intent.getBooleanExtra(INTENT_PER_APP, false);
        final String[] appList = intent.getStringArrayExtra(INTENT_APP_LIST);
        final FragmentConfig fragmentConfig;
        try { fragmentConfig = FragmentConfig.parse(intent.getStringExtra(INTENT_FRAGMENT_CONFIG)); }
        catch (Exception e) { Log.e(TAG, "Invalid Fragment JSON", e); stopSelf(); return START_NOT_STICKY; }

        startForegroundNotification(name);
        if (!configureVpn(name, perApp, appList)) {
            Log.e(TAG, "Could not establish VPN interface or per-app list is empty");
            stopMe();
            return START_NOT_STICKY;
        }

        final int fd = vpnInterface.getFd();
        new Thread(() -> startTunnel(fd, fragmentConfig), "Frago-VPN-Start").start();
        return START_STICKY;
    }

    private void startForegroundNotification(String name) {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "net.typeblog.socks";
            NotificationChannel channel = new NotificationChannel(channelId,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN);
            NotificationManager manager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(manager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), flags);
        startForeground(1, builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .build());
    }

    private boolean configureVpn(String name, boolean perApp, String[] apps) {
        Builder builder = new Builder();
        builder.setMtu(1500)
                .setSession(TextUtils.isEmpty(name) ? "Frago" : name)
                .addAddress("26.26.26.1", 24)
                .addDnsServer("26.26.26.1")
                .addRoute("0.0.0.0", 0)
                .addRoute("8.8.8.8", 32);

        if (perApp) {
            int added = 0;
            if (apps != null) {
                for (String packageName : apps) {
                    if (TextUtils.isEmpty(packageName) || packageName.trim().equals(getPackageName())) continue;
                    try {
                        builder.addAllowedApplication(packageName.trim());
                        added++;
                    } catch (Exception e) {
                        Log.w(TAG, "Cannot include app " + packageName, e);
                    }
                }
            }
            if (added == 0) return false;
        } else {
            try { builder.addDisallowedApplication(getPackageName()); }
            catch (Exception e) { Log.w(TAG, "Cannot exclude Frago", e); }
        }
        vpnInterface = builder.establish();
        return vpnInterface != null;
    }

    private void startTunnel(int fd, FragmentConfig fragmentConfig) {
        if (stopping) return;
        int socksPort = fragmentConfig.socksPort;
        FragmentSocks5Engine bridge = new FragmentSocks5Engine(this, fragmentConfig);
        socksServer = bridge;
        if (!bridge.start() || stopping) {
            Log.e(TAG, "Local SOCKS5 engine failed to start");
            stopMe();
            return;
        }

        Utility.makePdnsdConf(this, fragmentConfig.dnsServer, fragmentConfig.dnsPort);
        String dnsCommand = String.format(Locale.US, "%s/libpdnsd.so -c %s/pdnsd.conf",
                getApplicationInfo().nativeLibraryDir, getFilesDir());
        if (Utility.exec(dnsCommand) != 0) {
            Log.e(TAG, "DNS gateway failed to start");
            stopMe();
            return;
        }

        String command = String.format(Locale.US,
                "%s/libtun2socks.so --netif-ipaddr 26.26.26.2"
                        + " --netif-netmask 255.255.255.0"
                        + " --socks-server-addr 127.0.0.1:%d"
                        + " --tunfd %d"
                        + " --tunmtu 1500"
                        + " --loglevel 3"
                        + " --pid %s/tun2socks.pid"
                        + " --sock %s/sock_path"
                        + " --dnsgw 26.26.26.1:8091",
                getApplicationInfo().nativeLibraryDir, socksPort, fd,
                getFilesDir(), getApplicationInfo().dataDir);

        if (DEBUG) Log.d(TAG, command);
        if (Utility.exec(command) != 0) {
            Log.e(TAG, "tun2socks failed to start");
            stopMe();
            return;
        }

        for (int i = 0; i < 5 && !stopping; i++) {
            if (System.sendfd(fd, getApplicationInfo().dataDir + "/sock_path") != -1) {
                running = true;
                return;
            }
            try { Thread.sleep(1000L * (i + 1)); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        if (!stopping) stopMe();
    }

    private void stopMe() {
        stopping = true;
        running = false;
        stopForeground(true);
        Utility.killPidFile(getFilesDir() + "/tun2socks.pid");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid");
        FragmentSocks5Engine bridge = socksServer;
        socksServer = null;
        if (bridge != null) bridge.stop();
        if (vpnInterface != null) {
            try {
                System.jniclose(vpnInterface.getFd());
                vpnInterface.close();
            } catch (Exception e) { Log.w(TAG, "Could not close VPN interface", e); }
            vpnInterface = null;
        }
        stopSelf();
    }

    @Override public void onRevoke() {
        super.onRevoke();
        stopMe();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onDestroy() {
        stopMe();
        super.onDestroy();
    }
}
