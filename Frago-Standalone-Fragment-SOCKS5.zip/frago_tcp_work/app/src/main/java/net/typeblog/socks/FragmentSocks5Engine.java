package net.typeblog.socks;

import android.net.VpnService;
import android.util.Log;

import net.typeblog.socks.util.FragmentConfig;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;

/** Frago's own SOCKS5 CONNECT server and best-effort TLS ClientHello fragmenter. */
final class FragmentSocks5Engine {
    private static final String TAG = "FragoSOCKS5";
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int HANDSHAKE_TIMEOUT_MS = 15000;

    private final VpnService vpn;
    private final FragmentConfig config;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private ServerSocket listener;
    private Thread acceptThread;

    FragmentSocks5Engine(VpnService vpn, FragmentConfig config) {
        this.vpn = vpn;
        this.config = config;
    }

    boolean start() {
        try {
            listener = new ServerSocket();
            listener.setReuseAddress(true);
            listener.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), config.socksPort));
            running.set(true);
            acceptThread = new Thread(() -> {
                while (running.get()) {
                    try {
                        final Socket client = listener.accept();
                        workers.execute(() -> handle(client));
                    } catch (SocketException e) {
                        if (running.get()) Log.e(TAG, "SOCKS5 accept failed", e);
                    } catch (Exception e) {
                        if (running.get()) Log.e(TAG, "SOCKS5 worker could not start", e);
                    }
                }
            }, "Frago-SOCKS5-Accept");
            acceptThread.start();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Cannot bind local SOCKS5 listener", e);
            stop();
            return false;
        }
    }

    private void handle(Socket client) {
        Socket remote = null;
        try (Socket local = client) {
            local.setTcpNoDelay(true);
            local.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
            InputStream in = local.getInputStream();
            OutputStream out = local.getOutputStream();

            // RFC 1928 greeting; the private loopback listener deliberately uses no-auth only.
            int version = in.read();
            int methodCount = in.read();
            if (version != 5 || methodCount < 1) return;
            byte[] methods = readExact(in, methodCount);
            boolean noAuthOffered = false;
            for (byte method : methods) {
                if ((method & 0xff) == 0) noAuthOffered = true;
            }
            out.write(new byte[]{5, (byte) (noAuthOffered ? 0 : 0xff)});
            out.flush();
            if (!noAuthOffered) return;

            int requestVersion = in.read();
            int command = in.read();
            int reserved = in.read();
            int addressType = in.read();
            if (requestVersion != 5 || reserved != 0) {
                writeReply(out, 1);
                return;
            }
            if (command != 1) { // CONNECT only; UDP ASSOCIATE is intentionally unsupported.
                writeReply(out, 7);
                return;
            }

            String host;
            if (addressType == 1) {
                host = InetAddress.getByAddress(readExact(in, 4)).getHostAddress();
            } else if (addressType == 3) {
                int length = in.read();
                if (length < 1) return;
                host = new String(readExact(in, length), "UTF-8");
            } else if (addressType == 4) {
                host = InetAddress.getByAddress(readExact(in, 16)).getHostAddress();
            } else {
                writeReply(out, 8);
                return;
            }

            byte[] portBytes = readExact(in, 2);
            int destinationPort = ((portBytes[0] & 0xff) << 8) | (portBytes[1] & 0xff);
            if (destinationPort < 1) {
                writeReply(out, 1);
                return;
            }

            remote = new Socket();
            // Critical: an upstream socket must be excluded from this VPN to avoid a routing loop.
            if (!vpn.protect(remote)) {
                writeReply(out, 1);
                throw new IOException("VpnService.protect() failed");
            }
            try {
                remote.connect(new InetSocketAddress(host, destinationPort), CONNECT_TIMEOUT_MS);
            } catch (UnknownHostException e) {
                writeReply(out, 4);
                return;
            } catch (NoRouteToHostException e) {
                writeReply(out, 3);
                return;
            } catch (ConnectException e) {
                writeReply(out, 5);
                return;
            } catch (SocketTimeoutException e) {
                writeReply(out, 6);
                return;
            } catch (IOException e) {
                writeReply(out, 1);
                return;
            }

            remote.setTcpNoDelay(true);
            remote.setSoTimeout(0);
            local.setSoTimeout(0);
            writeReply(out, 0);

            final Socket connected = remote;
            workers.execute(() -> copyRemoteToClient(connected, local));
            copyClientToRemote(in, remote.getOutputStream(), config.shouldFragmentHost(host));
        } catch (Exception e) {
            Log.d(TAG, "SOCKS5 session ended: " + e.getMessage());
        } finally {
            close(remote);
        }
    }

    private void copyClientToRemote(InputStream in, OutputStream out, boolean applyFragment) throws Exception {
        if (applyFragment) {
            byte[] firstRecord = readFirstTlsRecord(in);
            if (firstRecord != null) writeFragmented(out, firstRecord);
        }
        byte[] buffer = new byte[16 * 1024];
        int count;
        while ((count = in.read(buffer)) != -1) {
            out.write(buffer, 0, count);
            out.flush();
        }
    }

    /** Buffers only the first TLS record; all non-TLS data is forwarded unchanged. */
    private byte[] readFirstTlsRecord(InputStream in) throws Exception {
        int first = in.read();
        if (first < 0) return null;
        byte[] header = new byte[5];
        header[0] = (byte) first;
        readFully(in, header, 1, 4);
        int recordLength = ((header[3] & 0xff) << 8) | (header[4] & 0xff);
        if ((header[0] & 0xff) != 22 || (header[1] & 0xff) != 3
                || recordLength < 1 || recordLength > 18432) {
            return header;
        }
        byte[] payload = readExact(in, recordLength);
        byte[] record = new byte[5 + recordLength];
        java.lang.System.arraycopy(header, 0, record, 0, 5);
        java.lang.System.arraycopy(payload, 0, record, 5, recordLength);
        return record;
    }

    private void writeFragmented(OutputStream out, byte[] record) throws Exception {
        // Only split a TLS ClientHello. Other TLS records pass through unchanged.
        if (record.length < 6 || (record[0] & 0xff) != 22 || (record[5] & 0xff) != 1) {
            out.write(record);
            out.flush();
            return;
        }

        int offset = 0;
        while (offset < record.length) {
            int chunkSize = config.minLength + ThreadLocalRandom.current().nextInt(
                    Math.max(1, config.maxLength - config.minLength + 1));
            int count = Math.min(chunkSize, record.length - offset);
            out.write(record, offset, count);
            out.flush();
            offset += count;
            if (offset < record.length && config.maxInterval > 0) {
                int delay = config.minInterval + ThreadLocalRandom.current().nextInt(
                        Math.max(1, config.maxInterval - config.minInterval + 1));
                if (delay > 0) Thread.sleep(delay);
            }
        }
    }

    private void copyRemoteToClient(Socket remote, Socket client) {
        try {
            InputStream in = remote.getInputStream();
            OutputStream out = client.getOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
                out.flush();
            }
        } catch (Exception ignored) {
        } finally {
            close(client);
            close(remote);
        }
    }

    private static byte[] readExact(InputStream in, int length) throws IOException {
        byte[] result = new byte[length];
        readFully(in, result, 0, length);
        return result;
    }

    private static void readFully(InputStream in, byte[] buffer, int offset, int length) throws IOException {
        while (length > 0) {
            int count = in.read(buffer, offset, length);
            if (count < 0) throw new EOFException("Unexpected end of SOCKS5/TLS data");
            offset += count;
            length -= count;
        }
    }

    private static void writeReply(OutputStream out, int result) throws IOException {
        out.write(new byte[]{5, (byte) result, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    private static void close(Socket socket) {
        if (socket != null) {
            try { socket.close(); } catch (Exception ignored) { }
        }
    }

    void stop() {
        running.set(false);
        if (listener != null) {
            try { listener.close(); } catch (Exception ignored) { }
        }
        workers.shutdownNow();
    }
}
