# Frago — TCP Fragment experimental build (lean source)

This package removes the Xray runtime and uses Android `VpnService`, prebuilt ARM64 `system`, `tun2socks`, and `pdnsd` libraries, plus an in-app SOCKS5 CONNECT bridge.

The native runtime binaries are retained under `app/src/main/jniLibs/arm64-v8a`. The large native source tree and its manual build script are omitted to reduce archive size. Gradle packages the retained prebuilt libraries; rebuilding or modifying those native libraries requires the full source archive.

This is a best-effort TCP-only replacement, not a wire-equivalent implementation of Xray's `freedom.fragment`. Splitting Java socket writes does **not** guarantee that the operating system emits separate TCP segments; TCP may coalesce writes. UDP proxying, QUIC/HTTP3, Xray routing rules, Xray DoH configuration, and Xray outbound protocols are not supported by the new bridge.
