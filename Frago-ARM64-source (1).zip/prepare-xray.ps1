$ErrorActionPreference = 'Stop'

$version = 'v26.11.9'
$url = "https://github.com/XTLS/Xray-core/releases/download/$version/Xray-android-arm64-v8a.zip"
$expectedSha256 = 'edcefc25b9b3195b11e18624c8269a969d6aabc39c6298a9a5ab29de15d46f3b'

$tempRoot = Join-Path $env:TEMP 'SocksDroid-Xray-ARM64'
$archive = Join-Path $tempRoot 'Xray-android-arm64-v8a.zip'
$extractDir = Join-Path $tempRoot 'extract'
$targetDir = Join-Path $PSScriptRoot 'app\src\main\jniLibs\arm64-v8a'
$targetFile = Join-Path $targetDir 'libxray.so'

New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $extractDir | Out-Null

Write-Host "Downloading official Xray Android ARM64 $version ..." -ForegroundColor Cyan
Invoke-WebRequest -Uri $url -OutFile $archive

$actualSha256 = (Get-FileHash -Path $archive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualSha256 -ne $expectedSha256) {
    throw "SHA-256 mismatch. Expected $expectedSha256, got $actualSha256. The archive will not be used."
}
Write-Host 'SHA-256 verified.' -ForegroundColor Green

Expand-Archive -Path $archive -DestinationPath $extractDir -Force
$xrayFile = Get-ChildItem -Path $extractDir -Recurse -File | Where-Object { $_.Name -eq 'xray' } | Select-Object -First 1
if (-not $xrayFile) {
    throw 'The downloaded archive does not contain the expected xray executable.'
}

New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
Copy-Item -Path $xrayFile.FullName -Destination $targetFile -Force
Write-Host "Xray engine installed for packaging: $targetFile" -ForegroundColor Green
Write-Host 'Now open this project in Android Studio and build the debug APK.' -ForegroundColor Green
