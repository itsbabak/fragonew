package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.content.ServiceConnection;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.ListPreference;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import static net.typeblog.socks.util.Constants.*;

public class ProfileFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {
    private static final int REQUEST_IMPORT_XRAY = 1001;

    private ProfileManager mManager;
    private Profile mProfile;

    private Switch mSwitch;
    private boolean mRunning = false;
    private boolean mStarting = false, mStopping = false;
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName p1, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);

            try {
                mRunning = mBinder.isRunning();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (mRunning) {
                updateState();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName p1) {
            mBinder = null;
        }
    };
    private final Runnable mStateRunnable = new Runnable() {
        @Override
        public void run() {
            updateState();
            if (mSwitch != null) mSwitch.postDelayed(this, 5000);
        }
    };
    private IVpnService mBinder;

    private ListPreference mPrefProfile, mPrefRoutes;
    private EditTextPreference mPrefServer, mPrefPort, mPrefUsername, mPrefPassword,
            mPrefDns, mPrefDnsPort, mPrefAppList, mPrefUDPGW;
    private CheckBoxPreference mPrefUserpw, mPrefPerApp, mPrefAppBypass, mPrefIPv6, mPrefUDP, mPrefAuto, mPrefXrayMode;
    private Preference mPrefXrayImport, mPrefXrayEdit, mPrefProxyLink, mPrefAppPicker;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        setHasOptionsMenu(true);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);

        MenuItem s = menu.findItem(R.id.switch_main);
        mSwitch = s.getActionView().findViewById(R.id.switch_action_button);
        mSwitch.setOnCheckedChangeListener(this);
        mSwitch.postDelayed(mStateRunnable, 5000);
        checkState();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.postDelayed(mStateRunnable, 5000);
        }
    }

    @Override
    public void onPause() {
        if (mSwitch != null) mSwitch.removeCallbacks(mStateRunnable);
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
        }
        super.onDestroyView();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.prof_add) {
            addProfile();
            return true;
        } else if (id == R.id.prof_del) {
            removeProfile();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPreferenceClick(Preference p) {
        if (p == mPrefXrayImport) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, REQUEST_IMPORT_XRAY);
            return true;
        } else if (p == mPrefXrayEdit) {
            editXrayJson();
            return true;
        } else if (p == mPrefProxyLink) {
            importProxyLinkDialog();
            return true;
        } else if (p == mPrefAppPicker) {
            showAppPicker();
            return true;
        }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference p, Object newValue) {
        if (p == mPrefProfile) {
            String name = newValue.toString();
            mProfile = mManager.getProfile(name);
            mManager.switchDefault(name);
            reload();
            return true;
        } else if (p == mPrefServer) {
            mProfile.setServer(newValue.toString());
            resetTextN(mPrefServer, newValue);
            return true;
        } else if (p == mPrefPort) {
            if (TextUtils.isEmpty(newValue.toString()))
                return false;

            mProfile.setPort(Integer.parseInt(newValue.toString()));
            resetTextN(mPrefPort, newValue);
            return true;
        } else if (p == mPrefUserpw) {
            mProfile.setIsUserpw(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefUsername) {
            mProfile.setUsername(newValue.toString());
            resetTextN(mPrefUsername, newValue);
            return true;
        } else if (p == mPrefPassword) {
            mProfile.setPassword(newValue.toString());
            resetTextN(mPrefPassword, newValue);
            return true;
        } else if (p == mPrefRoutes) {
            mProfile.setRoute(newValue.toString());
            resetListN(mPrefRoutes, newValue);
            return true;
        } else if (p == mPrefDns) {
            mProfile.setDns(newValue.toString());
            resetTextN(mPrefDns, newValue);
            return true;
        } else if (p == mPrefDnsPort) {
            if (TextUtils.isEmpty(newValue.toString()))
                return false;

            mProfile.setDnsPort(Integer.parseInt(newValue.toString()));
            resetTextN(mPrefDnsPort, newValue);
            return true;
        } else if (p == mPrefPerApp) {
            mProfile.setIsPerApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefAppList) {
            mProfile.setAppList(newValue.toString());
            return true;
        } else if (p == mPrefIPv6) {
            mProfile.setHasIPv6(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefUDP) {
            mProfile.setHasUDP(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefUDPGW) {
            mProfile.setUDPGW(newValue.toString());
            resetTextN(mPrefUDPGW, newValue);
            return true;
        } else if (p == mPrefAuto) {
            mProfile.setAutoConnect(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefXrayMode) {
            mProfile.setXrayMode(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton p1, boolean checked) {
        if (checked) {
            startVpn();
        } else {
            stopVpn();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMPORT_XRAY) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                importXrayJson(data.getData());
            }
            return;
        }

        if (requestCode == 0 && resultCode == Activity.RESULT_OK) {
            Utility.startVpn(getActivity(), mProfile);
            checkState();
        }
    }

    private void importXrayJson(Uri uri) {
        InputStream in = null;
        try {
            in = getActivity().getContentResolver().openInputStream(uri);
            if (in == null) throw new IllegalArgumentException("Unable to open the selected file.");

            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                json.append(line).append('\n');
                if (json.length() > 1024 * 1024) {
                    throw new IllegalArgumentException("JSON file is larger than 1 MB.");
                }
            }

            XrayConfig.Prepared prepared = XrayConfig.prepare(json.toString());
            mProfile.setXrayConfig(prepared.json);
            mProfile.setXrayMode(true);
            mPrefXrayMode.setChecked(true);
            mPrefXrayImport.setSummary(getString(R.string.xray_imported_sum, prepared.socksPort));
            mPrefXrayEdit.setEnabled(true);
            Toast.makeText(getActivity(), R.string.xray_import_ok, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getActivity(), getString(R.string.xray_import_error, e.getMessage()), Toast.LENGTH_LONG).show();
        } finally {
            if (in != null) {
                try { in.close(); } catch (Exception ignored) { }
            }
        }
    }

    private void saveXrayConfig(String raw) {
        try {
            XrayConfig.Prepared prepared = XrayConfig.prepare(raw);
            mProfile.setXrayConfig(prepared.json);
            mProfile.setXrayMode(true);
            mPrefXrayMode.setChecked(true);
            mPrefXrayImport.setSummary(getString(R.string.xray_imported_sum, prepared.socksPort));
            mPrefXrayEdit.setEnabled(true);
            Toast.makeText(getActivity(), R.string.xray_import_ok, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getActivity(), getString(R.string.xray_import_error, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void editXrayJson() {
        String current = mProfile.getXrayConfig();
        if (TextUtils.isEmpty(current)) {
            Toast.makeText(getActivity(), R.string.xray_edit_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(current);
        editor.setSelection(0);
        editor.setMinLines(12);
        editor.setMaxLines(20);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.xray_edit)
                .setView(editor)
                .setPositiveButton(R.string.xray_save, (dialog, which) ->
                        saveXrayConfig(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void importProxyLinkDialog() {
        final EditText input = new EditText(getActivity());
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setHint("vless://...  یا  http://...");
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.proxy_link_title)
                .setView(input)
                .setPositiveButton(R.string.xray_save, (dialog, which) -> {
                    try {
                        String json = net.typeblog.socks.util.ProxyUriConfig.toXrayJson(
                                input.getText().toString().trim());
                        saveXrayConfig(json);
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), getString(R.string.xray_import_error,
                                e.getMessage()), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showAppPicker() {
        final PackageManager pm = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = pm.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(pm));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = mProfile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\n")) {
                if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
            }
        }

        for (ResolveInfo info : resolved) {
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            labels.add(info.loadLabel(pm) + "\n" + packageName);
        }

        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), R.string.adv_app_picker_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.adv_app_picker)
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(R.string.xray_save, (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) {
                        if (checked[i]) {
                            if (list.length() > 0) list.append('\n');
                            list.append(packages.get(i));
                        }
                    }
                    if (list.length() == 0) {
                        Toast.makeText(getActivity(), R.string.adv_app_picker_empty, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    mProfile.setAppList(list.toString());
                    mProfile.setIsPerApp(true);
                    mPrefPerApp.setChecked(true);
                    mPrefAppList.setText(list.toString());
                    Toast.makeText(getActivity(), R.string.adv_app_picker_saved, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void initPreferences() {
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mPrefServer = (EditTextPreference) findPreference(PREF_SERVER_IP);
        mPrefPort = (EditTextPreference) findPreference(PREF_SERVER_PORT);
        mPrefUserpw = (CheckBoxPreference) findPreference(PREF_AUTH_USERPW);
        mPrefUsername = (EditTextPreference) findPreference(PREF_AUTH_USERNAME);
        mPrefPassword = (EditTextPreference) findPreference(PREF_AUTH_PASSWORD);
        mPrefRoutes = (ListPreference) findPreference(PREF_ADV_ROUTE);
        mPrefDns = (EditTextPreference) findPreference(PREF_ADV_DNS);
        mPrefDnsPort = (EditTextPreference) findPreference(PREF_ADV_DNS_PORT);
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefAppList = (EditTextPreference) findPreference(PREF_ADV_APP_LIST);
        mPrefIPv6 = (CheckBoxPreference) findPreference(PREF_IPV6_PROXY);
        mPrefUDP = (CheckBoxPreference) findPreference(PREF_UDP_PROXY);
        mPrefUDPGW = (EditTextPreference) findPreference(PREF_UDP_GW);
        mPrefAuto = (CheckBoxPreference) findPreference(PREF_ADV_AUTO_CONNECT);
        mPrefXrayMode = (CheckBoxPreference) findPreference(PREF_XRAY_MODE);
        mPrefXrayImport = findPreference(PREF_XRAY_IMPORT);
        mPrefXrayEdit = findPreference("xray_config_edit");
        mPrefProxyLink = findPreference("proxy_link_import");
        mPrefAppPicker = findPreference("adv_app_picker");

        mPrefProfile.setOnPreferenceChangeListener(this);
        mPrefServer.setOnPreferenceChangeListener(this);
        mPrefPort.setOnPreferenceChangeListener(this);
        mPrefUserpw.setOnPreferenceChangeListener(this);
        mPrefUsername.setOnPreferenceChangeListener(this);
        mPrefPassword.setOnPreferenceChangeListener(this);
        mPrefRoutes.setOnPreferenceChangeListener(this);
        mPrefDns.setOnPreferenceChangeListener(this);
        mPrefDnsPort.setOnPreferenceChangeListener(this);
        mPrefPerApp.setOnPreferenceChangeListener(this);
        mPrefAppBypass.setOnPreferenceChangeListener(this);
        mPrefAppList.setOnPreferenceChangeListener(this);
        mPrefIPv6.setOnPreferenceChangeListener(this);
        mPrefUDP.setOnPreferenceChangeListener(this);
        mPrefUDPGW.setOnPreferenceChangeListener(this);
        mPrefAuto.setOnPreferenceChangeListener(this);
        mPrefXrayMode.setOnPreferenceChangeListener(this);
        mPrefXrayImport.setOnPreferenceClickListener(this);
        mPrefXrayEdit.setOnPreferenceClickListener(this);
        mPrefProxyLink.setOnPreferenceClickListener(this);
        mPrefAppPicker.setOnPreferenceClickListener(this);
    }

    private void reload() {
        if (mProfile == null) {
            mProfile = mManager.getDefault();
        }

        mPrefProfile.setEntries(mManager.getProfiles());
        mPrefProfile.setEntryValues(mManager.getProfiles());
        mPrefProfile.setValue(mProfile.getName());
        mPrefRoutes.setValue(mProfile.getRoute());
        resetList(mPrefProfile, mPrefRoutes);

        mPrefUserpw.setChecked(mProfile.isUserPw());
        mPrefPerApp.setChecked(mProfile.isPerApp());
        mPrefAppBypass.setChecked(mProfile.isBypassApp());
        mPrefIPv6.setChecked(mProfile.hasIPv6());
        mPrefUDP.setChecked(mProfile.hasUDP());
        mPrefAuto.setChecked(mProfile.autoConnect());
        mPrefXrayMode.setChecked(mProfile.isXrayMode());
        mPrefXrayEdit.setEnabled(!TextUtils.isEmpty(mProfile.getXrayConfig()));
        if (!TextUtils.isEmpty(mProfile.getXrayConfig())) {
            try {
                XrayConfig.Prepared xray = XrayConfig.prepare(mProfile.getXrayConfig());
                mPrefXrayImport.setSummary(getString(R.string.xray_imported_sum, xray.socksPort));
            } catch (Exception e) {
                mPrefXrayImport.setSummary(R.string.xray_import_sum);
            }
        } else {
            mPrefXrayImport.setSummary(R.string.xray_import_sum);
        }

        mPrefServer.setText(mProfile.getServer());
        mPrefPort.setText(String.valueOf(mProfile.getPort()));
        mPrefUsername.setText(mProfile.getUsername());
        mPrefPassword.setText(mProfile.getPassword());
        mPrefDns.setText(mProfile.getDns());
        mPrefDnsPort.setText(String.valueOf(mProfile.getDnsPort()));
        mPrefUDPGW.setText(mProfile.getUDPGW());
        resetText(mPrefServer, mPrefPort, mPrefUsername, mPrefPassword, mPrefDns, mPrefDnsPort, mPrefUDPGW);

        mPrefAppList.setText(mProfile.getAppList());
    }

    private void resetList(ListPreference... pref) {
        for (ListPreference p : pref)
            p.setSummary(p.getEntry());
    }

    private void resetListN(ListPreference pref, Object newValue) {
        pref.setSummary(newValue.toString());
    }

    private void resetText(EditTextPreference... pref) {
        for (EditTextPreference p : pref) {
            if ((p.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                p.setSummary(p.getText());
            } else {
                if (p.getText().length() > 0)
                    p.setSummary(String.format(Locale.US,
                            String.format(Locale.US, "%%0%dd", p.getText().length()), 0)
                            .replace("0", "*"));
                else
                    p.setSummary("");
            }
        }
    }

    private void resetTextN(EditTextPreference pref, Object newValue) {
        if ((pref.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
            pref.setSummary(newValue.toString());
        } else {
            String text = newValue.toString();
            if (text.length() > 0)
                pref.setSummary(String.format(Locale.US,
                        String.format(Locale.US, "%%0%dd", text.length()), 0)
                        .replace("0", "*"));
            else
                pref.setSummary("");
        }
    }

    private void addProfile() {
        final EditText e = new EditText(getActivity());
        e.setSingleLine(true);

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(e)
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    String name = e.getText().toString().trim();

                    if (!TextUtils.isEmpty(name)) {
                        Profile p = mManager.addProfile(name);

                        if (p != null) {
                            mProfile = p;
                            reload();
                            return;
                        }
                    }

                    Toast.makeText(getActivity(),
                            String.format(getString(R.string.err_add_prof), name),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(String.format(getString(R.string.prof_del_confirm), mProfile.getName()))
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(),
                                getString(R.string.err_del_prof, mProfile.getName()),
                                Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private void checkState() {
        mRunning = false;
        mSwitch.setEnabled(false);
        mSwitch.setOnCheckedChangeListener(null);

        if (mBinder == null) {
            getActivity().bindService(new Intent(getActivity(), SocksVpnService.class), mConnection, 0);
        }
    }

    private void updateState() {
        if (mBinder == null) {
            mRunning = false;
        } else {
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception e) {
                mRunning = false;
            }
        }

        mSwitch.setChecked(mRunning);

        if ((!mStarting && !mStopping) || (mStarting && mRunning) || (mStopping && !mRunning)) {
            mSwitch.setEnabled(true);
        }

        if (mStarting && mRunning) {
            mStarting = false;
        }

        if (mStopping && !mRunning) {
            mStopping = false;
        }

        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void startVpn() {
        mStarting = true;
        Intent i = VpnService.prepare(getActivity());

        if (i != null) {
            startActivityForResult(i, 0);
        } else {
            onActivityResult(0, Activity.RESULT_OK, null);
        }
    }

    private void stopVpn() {
        if (mBinder == null)
            return;

        mStopping = true;

        try {
            mBinder.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }

        mBinder = null;

        getActivity().unbindService(mConnection);
        checkState();
    }
}
