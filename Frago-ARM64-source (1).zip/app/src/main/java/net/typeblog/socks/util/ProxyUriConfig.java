package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import android.util.Base64;
import java.util.Map;

/** Converts common proxy share URIs into a minimal Xray profile used by SocksDroid. */
public final class ProxyUriConfig {
    private ProxyUriConfig() {}

    public static String toXrayJson(String value) throws Exception {
        URI uri = new URI(value.trim());
        String scheme = uri.getScheme();
        if (scheme == null) throw new IllegalArgumentException("لینک معتبر نیست.");

        JSONObject root = new JSONObject();
        JSONArray inbounds = new JSONArray();
        JSONObject inbound = new JSONObject();
        inbound.put("listen", "127.0.0.1");
        inbound.put("port", 10808);
        inbound.put("protocol", "socks");
        JSONObject inboundSettings = new JSONObject();
        inboundSettings.put("auth", "noauth");
        inboundSettings.put("udp", true);
        inbound.put("settings", inboundSettings);
        inbounds.put(inbound);
        root.put("inbounds", inbounds);

        JSONObject outbound = new JSONObject();
        outbound.put("tag", "proxy");
        JSONObject settings = new JSONObject();

        if ("ss".equalsIgnoreCase(scheme)) {
            if (uri.getRawQuery() != null && uri.getRawQuery().toLowerCase().contains("plugin=")) {
                throw new IllegalArgumentException("افزونه‌های Shadowsocks در این نسخه پشتیبانی نمی‌شوند؛ لینک بدون plugin وارد کنید.");
            }
            String method = null;
            String password = null;
            String host = uri.getHost();
            int proxyPort = uri.getPort();
            String userInfo = uri.getRawUserInfo();

            // SIP002 form: ss://BASE64(method:password)@host:port
            if (host != null && proxyPort > 0 && userInfo != null) {
                String decoded = decodeShadowsocksUserInfo(userInfo);
                int separator = decoded.indexOf(':');
                if (separator <= 0 || separator == decoded.length() - 1)
                    throw new IllegalArgumentException("اطلاعات رمزنگاری Shadowsocks معتبر نیست.");
                method = decoded.substring(0, separator);
                password = decoded.substring(separator + 1);
            } else {
                // Legacy form: ss://BASE64(method:password@host:port)
                String encoded = uri.getRawSchemeSpecificPart();
                int fragment = encoded.indexOf('#');
                if (fragment >= 0) encoded = encoded.substring(0, fragment);
                int queryIndex = encoded.indexOf('?');
                if (queryIndex >= 0) encoded = encoded.substring(0, queryIndex);
                String decoded = decodeShadowsocksUserInfo(encoded);
                URI legacy = new URI("ss://" + decoded);
                host = legacy.getHost();
                proxyPort = legacy.getPort();
                String legacyUser = legacy.getRawUserInfo();
                if (host == null || proxyPort < 1 || legacyUser == null)
                    throw new IllegalArgumentException("لینک Shadowsocks معتبر نیست.");
                int separator = legacyUser.indexOf(':');
                if (separator <= 0 || separator == legacyUser.length() - 1)
                    throw new IllegalArgumentException("اطلاعات رمزنگاری Shadowsocks معتبر نیست.");
                method = decode(legacyUser.substring(0, separator));
                password = decode(legacyUser.substring(separator + 1));
            }

            if (host == null || proxyPort < 1 || proxyPort > 65535)
                throw new IllegalArgumentException("آدرس یا پورت Shadowsocks معتبر نیست.");
            if (method == null || method.trim().isEmpty() || password == null || password.isEmpty())
                throw new IllegalArgumentException("روش رمزنگاری و رمز Shadowsocks الزامی است.");

            JSONObject server = new JSONObject();
            server.put("address", host);
            server.put("port", proxyPort);
            server.put("method", method);
            server.put("password", password);
            settings.put("servers", new JSONArray().put(server));
            outbound.put("protocol", "shadowsocks");
        } else if ("vless".equalsIgnoreCase(scheme)) {
            if (uri.getHost() == null || uri.getPort() < 1 || uri.getPort() > 65535)
                throw new IllegalArgumentException("آدرس یا پورت VLESS معتبر نیست.");
            String uuid = uri.getUserInfo();
            if (uuid == null || uuid.trim().isEmpty())
                throw new IllegalArgumentException("شناسه UUID در لینک VLESS وجود ندارد.");

            Map<String, String> q = query(uri.getRawQuery());
            JSONObject user = new JSONObject();
            user.put("id", decode(uuid));
            user.put("encryption", q.containsKey("encryption") ? q.get("encryption") : "none");
            if (q.containsKey("flow") && !q.get("flow").isEmpty()) user.put("flow", q.get("flow"));
            JSONArray users = new JSONArray().put(user);
            JSONObject server = new JSONObject();
            server.put("address", uri.getHost());
            server.put("port", uri.getPort());
            server.put("users", users);
            settings.put("vnext", new JSONArray().put(server));
            outbound.put("protocol", "vless");

            String network = q.getOrDefault("type", "tcp");
            String security = q.getOrDefault("security", "none");
            JSONObject stream = new JSONObject();
            stream.put("network", network);
            stream.put("security", security);
            if ("tls".equalsIgnoreCase(security)) {
                JSONObject tls = new JSONObject();
                if (q.containsKey("sni")) tls.put("serverName", q.get("sni"));
                if (q.containsKey("fp")) tls.put("fingerprint", q.get("fp"));
                stream.put("tlsSettings", tls);
            } else if ("reality".equalsIgnoreCase(security)) {
                JSONObject reality = new JSONObject();
                if (q.containsKey("sni")) reality.put("serverName", q.get("sni"));
                if (q.containsKey("fp")) reality.put("fingerprint", q.get("fp"));
                if (q.containsKey("pbk")) reality.put("publicKey", q.get("pbk"));
                if (q.containsKey("sid")) reality.put("shortId", q.get("sid"));
                if (q.containsKey("spx")) reality.put("spiderX", q.get("spx"));
                stream.put("realitySettings", reality);
            }
            if ("ws".equalsIgnoreCase(network)) {
                JSONObject ws = new JSONObject();
                if (q.containsKey("path")) ws.put("path", q.get("path"));
                if (q.containsKey("host")) ws.put("headers", new JSONObject().put("Host", q.get("host")));
                stream.put("wsSettings", ws);
            } else if ("grpc".equalsIgnoreCase(network)) {
                JSONObject grpc = new JSONObject();
                if (q.containsKey("serviceName")) grpc.put("serviceName", q.get("serviceName"));
                stream.put("grpcSettings", grpc);
            } else if ("httpupgrade".equalsIgnoreCase(network)) {
                JSONObject upgrade = new JSONObject();
                if (q.containsKey("path")) upgrade.put("path", q.get("path"));
                if (q.containsKey("host")) upgrade.put("host", q.get("host"));
                stream.put("httpupgradeSettings", upgrade);
            }
            outbound.put("streamSettings", stream);
        } else if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)
                || "socks".equalsIgnoreCase(scheme) || "socks5".equalsIgnoreCase(scheme)) {
            int proxyPort = uri.getPort();
            if (proxyPort < 0) {
                proxyPort = "https".equalsIgnoreCase(scheme) ? 443
                        : ("http".equalsIgnoreCase(scheme) ? 80 : 1080);
            }
            if (uri.getHost() == null || proxyPort < 1 || proxyPort > 65535)
                throw new IllegalArgumentException("آدرس یا پورت پروکسی معتبر نیست.");
            boolean socks = scheme.toLowerCase().startsWith("socks");
            outbound.put("protocol", socks ? "socks" : "http");
            JSONObject server = new JSONObject();
            server.put("address", uri.getHost());
            server.put("port", proxyPort);
            String info = uri.getRawUserInfo();
            if (info != null && !info.isEmpty()) {
                String[] pair = info.split(":", 2);
                JSONArray users = new JSONArray();
                JSONObject credentials = new JSONObject();
                credentials.put(socks ? "user" : "user", decode(pair[0]));
                if (pair.length > 1) credentials.put(socks ? "pass" : "pass", decode(pair[1]));
                users.put(credentials);
                server.put("users", users);
            }
            settings.put("servers", new JSONArray().put(server));
            if ("https".equalsIgnoreCase(scheme)) {
                outbound.put("streamSettings", new JSONObject()
                        .put("security", "tls")
                        .put("tlsSettings", new JSONObject().put("serverName", uri.getHost())));
            }
        } else {
            throw new IllegalArgumentException("پروتکل پشتیبانی نمی‌شود. VLESS، Shadowsocks، HTTP(S) و SOCKS5 قابل قبول‌اند.");
        }

        outbound.put("settings", settings);
        root.put("outbounds", new JSONArray().put(outbound).put(new JSONObject().put("protocol", "freedom").put("tag", "direct")));
        return root.toString(2);
    }

    private static String decodeShadowsocksUserInfo(String value) throws Exception {
        value = decode(value);
        String normalized = value.replace("-", "+").replace("_", "/");
        while (normalized.length() % 4 != 0) normalized += "=";
        try {
            return new String(Base64.decode(normalized, Base64.DEFAULT), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException standardError) {
            return new String(Base64.decode(value, Base64.URL_SAFE | Base64.NO_WRAP), StandardCharsets.UTF_8);
        }
    }

    private static Map<String, String> query(String raw) throws Exception {
        Map<String, String> result = new HashMap<>();
        if (raw == null || raw.isEmpty()) return result;
        for (String part : raw.split("&")) {
            String[] kv = part.split("=", 2);
            result.put(decode(kv[0]), kv.length > 1 ? decode(kv[1]) : "");
        }
        return result;
    }

    private static String decode(String value) throws Exception {
        return URLDecoder.decode(value.replace("+", "%2B"), "UTF-8");
    }
}
