package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;

import net.typeblog.socks.util.Routes;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Objects;

import static net.typeblog.socks.util.Constants.*;
import static net.typeblog.socks.BuildConfig.DEBUG;

public class SocksVpnService extends VpnService {
    class VpnBinder extends IVpnService.Stub {
        @Override
        public boolean isRunning() {
            return mRunning;
        }

        @Override
        public void stop() {
            stopMe();
        }
    }

    private static final String TAG = SocksVpnService.class.getSimpleName();
    private static final long XRAY_START_TIMEOUT_MS = 25000L;

    private ParcelFileDescriptor mInterface;
    private volatile boolean mRunning = false;
    private volatile boolean mStarting = false;
    private volatile boolean mStopping = false;
    private volatile Process mXrayProcess;
    private final IBinder mBinder = new VpnBinder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (DEBUG) Log.d(TAG, "starting");
        if (intent == null) return START_STICKY;
        if (mRunning || mStarting) return START_STICKY;

        mStopping = false;
        final String name = intent.getStringExtra(INTENT_NAME);
        String server = intent.getStringExtra(INTENT_SERVER);
        int port = intent.getIntExtra(INTENT_PORT, 1080);
        String username = intent.getStringExtra(INTENT_USERNAME);
        String passwd = intent.getStringExtra(INTENT_PASSWORD);
        final String route = intent.getStringExtra(INTENT_ROUTE);
        final String dns = intent.getStringExtra(INTENT_DNS);
        final int dnsPort = intent.getIntExtra(INTENT_DNS_PORT, 53);
        final boolean perApp = intent.getBooleanExtra(INTENT_PER_APP, false);
        final boolean appBypass = intent.getBooleanExtra(INTENT_APP_BYPASS, false);
        final String[] appList = intent.getStringArrayExtra(INTENT_APP_LIST);
        final boolean ipv6 = intent.getBooleanExtra(INTENT_IPV6_PROXY, false);
        final String udpgw = intent.getStringExtra(INTENT_UDP_GW);
        final boolean xrayMode = intent.getBooleanExtra(INTENT_XRAY_MODE, false);
        String xrayConfig = intent.getStringExtra(INTENT_XRAY_CONFIG);
        int xrayDnsPort = 0;

        if (xrayMode) {
            try {
                XrayConfig.Prepared prepared = XrayConfig.prepare(xrayConfig);
                xrayConfig = prepared.json;
                xrayDnsPort = prepared.dnsPort;
                server = "127.0.0.1";
                port = prepared.socksPort;
                username = null;
                passwd = null;
            } catch (Exception e) {
                Log.e(TAG, "Invalid Xray JSON", e);
                stopSelf();
                return START_NOT_STICKY;
            }
        }

        // Notifications on Oreo and above need a channel.
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "net.typeblog.socks";
            NotificationChannel channel = new NotificationChannel(channelId,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(notificationManager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }

        int notificationId = 1;
        int intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) intentFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), intentFlags);
        startForeground(notificationId, builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .build());

        configure(name, route, perApp, appBypass, appList, ipv6);
        if (mInterface == null) {
            Log.e(TAG, "Could not establish the VPN interface");
            stopMe();
            return START_NOT_STICKY;
        }

        if (DEBUG) Log.d(TAG, "TUN fd: " + mInterface.getFd());

        final String finalServer = server;
        final int finalPort = port;
        final String finalUsername = username;
        final String finalPasswd = passwd;
        final String finalXrayConfig = xrayConfig;
        final int finalXrayDnsPort = xrayDnsPort;
        final int interfaceFd = mInterface.getFd();
        mStarting = true;
        new Thread(() -> start(interfaceFd, finalServer, finalPort,
                finalUsername, finalPasswd, dns, dnsPort, ipv6, xrayMode,
                finalXrayConfig, finalXrayDnsPort, xrayMode ? null : udpgw), "SocksDroid-Connect").start();

        return START_STICKY;
    }

    @Override
    public void onRevoke() {
        super.onRevoke();
        stopMe();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        stopMe();
        super.onDestroy();
    }

    private void stopMe() {
        mStopping = true;
        mRunning = false;
        mStarting = false;
        stopForeground(true);

        Utility.killPidFile(getFilesDir() + "/tun2socks.pid");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid");

        Process xray = mXrayProcess;
        mXrayProcess = null;
        if (xray != null) {
            try { xray.destroy(); } catch (Exception e) { Log.w(TAG, "Could not stop Xray", e); }
        }

        if (mInterface != null) {
            try {
                System.jniclose(mInterface.getFd());
                mInterface.close();
            } catch (Exception e) {
                Log.w(TAG, "Could not close TUN interface", e);
            }
            mInterface = null;
        }

        stopSelf();
    }

    private void configure(String name, String route, boolean perApp, boolean bypass, String[] apps, boolean ipv6) {
        Builder b = new Builder();
        b.setMtu(1500)
                .setSession(name)
                .addAddress("26.26.26.1", 24)
                .addDnsServer("8.8.8.8");

        if (ipv6) {
            b.addAddress("fdfe:dcba:9876::1", 126).addRoute("::", 0);
        }

        Routes.addRoutes(this, b, route);
        // DNS packets are sent to the local pdnsd gateway; in Xray mode pdnsd
        // forwards them to Xray's private DNS inbound.
        b.addRoute("8.8.8.8", 32);

        if (!perApp) {
            try { b.addDisallowedApplication("net.typeblog.socks"); }
            catch (Exception e) { Log.w(TAG, "Could not bypass SocksDroid", e); }
        } else if (bypass) {
            try { b.addDisallowedApplication("net.typeblog.socks"); }
            catch (Exception e) { Log.w(TAG, "Could not bypass SocksDroid", e); }
            if (apps != null) {
                for (String p : apps) {
                    if (TextUtils.isEmpty(p)) continue;
                    try { b.addDisallowedApplication(p.trim()); }
                    catch (Exception e) { Log.w(TAG, "Could not bypass " + p, e); }
                }
            }
        } else if (apps != null) {
            for (String p : apps) {
                if (TextUtils.isEmpty(p) || p.trim().equals("net.typeblog.socks")) continue;
                try { b.addAllowedApplication(p.trim()); }
                catch (Exception e) { Log.w(TAG, "Could not include " + p, e); }
            }
        }

        mInterface = b.establish();
    }

    private void start(int fd, String server, int port, String user, String passwd,
                       String dns, int dnsPort, boolean ipv6, boolean xrayMode,
                       String xrayConfig, int xrayDnsPort, String udpgw) {
        if (mStopping) return;

        if (xrayMode) {
            if (!startXray(xrayConfig, port) || mStopping) {
                stopMe();
                return;
            }
            // Keep SocksDroid's small DNS gateway, but send its TCP upstream queries
            // into Xray's local DNS inbound so the imported DoH/DNS settings are honored.
            if (xrayDnsPort > 0) {
                Utility.makePdnsdConf(this, "127.0.0.1", xrayDnsPort);
            } else {
                Utility.makePdnsdConf(this, dns, dnsPort);
            }
        } else {
            Utility.makePdnsdConf(this, dns, dnsPort);
        }
        Utility.exec(String.format(Locale.US, "%s/libpdnsd.so -c %s/pdnsd.conf",
                getApplicationInfo().nativeLibraryDir, getFilesDir()));

        String command = String.format(Locale.US,
                "%s/libtun2socks.so --netif-ipaddr 26.26.26.2"
                        + " --netif-netmask 255.255.255.0"
                        + " --socks-server-addr %s:%d"
                        + " --tunfd %d"
                        + " --tunmtu 1500"
                        + " --loglevel 3"
                        + " --pid %s/tun2socks.pid"
                        + " --sock %s/sock_path",
                getApplicationInfo().nativeLibraryDir, server, port, fd,
                getFilesDir(), getApplicationInfo().dataDir);

        if (user != null) {
            command += " --username " + user;
            command += " --password " + passwd;
        }
        if (ipv6) command += " --netif-ip6addr fdfe:dcba:9876::2";

        // DNS is handled by the existing pdnsd gateway in both modes. In Xray mode
        // pdnsd forwards it to the local Xray DNS inbound configured above.
        command += " --dnsgw 26.26.26.1:8091";
        if (udpgw != null) command += " --udpgw-remote-server-addr " + udpgw;

        if (DEBUG) Log.d(TAG, command);
        if (Utility.exec(command) != 0) {
            Log.e(TAG, "tun2socks failed to start");
            stopMe();
            return;
        }

        for (int i = 0; i < 5 && !mStopping; i++) {
            if (System.sendfd(fd, getApplicationInfo().dataDir + "/sock_path") != -1) {
                mRunning = true;
                mStarting = false;
                return;
            }
            try { Thread.sleep(1000L * (i + 1)); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        if (!mStopping) stopMe();
    }

    private boolean startXray(String config, int socksPort) {
        try {
            if (TextUtils.isEmpty(config)) throw new IllegalArgumentException("No Xray JSON has been imported.");
            File core = new File(getApplicationInfo().nativeLibraryDir, "libxray.so");
            if (!core.exists()) throw new IllegalStateException("The bundled Xray engine is missing.");

            File configFile = new File(getFilesDir(), "xray-config.json");
            FileOutputStream out = new FileOutputStream(configFile, false);
            try { out.write(config.getBytes(Charset.forName("UTF-8"))); out.flush(); }
            finally { out.close(); }

            File logFile = new File(getFilesDir(), "xray.log");
            ProcessBuilder processBuilder = new ProcessBuilder(core.getAbsolutePath(),
                    "run", "-config", configFile.getAbsolutePath());
            processBuilder.directory(getFilesDir());
            processBuilder.redirectErrorStream(true);
            processBuilder.redirectOutput(logFile);
            Process process = processBuilder.start();
            mXrayProcess = process;

            long deadline = java.lang.System.currentTimeMillis() + XRAY_START_TIMEOUT_MS;
            while (!mStopping && java.lang.System.currentTimeMillis() < deadline) {
                if (!isProcessAlive(process)) {
                    Log.e(TAG, "Xray exited during startup. Check " + logFile.getAbsolutePath());
                    return false;
                }
                Socket socket = null;
                try {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress("127.0.0.1", socksPort), 350);
                    Log.i(TAG, "Xray SOCKS inbound ready on 127.0.0.1:" + socksPort);
                    return true;
                } catch (Exception ignored) {
                    // The local inbound may need a short moment to start.
                } finally {
                    if (socket != null) try { socket.close(); } catch (Exception ignored) { }
                }
                try { Thread.sleep(200L); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            Log.e(TAG, "Timed out waiting for Xray SOCKS inbound on port " + socksPort);
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Could not start bundled Xray engine", e);
            return false;
        }
    }

    private boolean isProcessAlive(Process process) {
        try {
            process.exitValue();
            return false;
        } catch (IllegalThreadStateException stillRunning) {
            return true;
        }
    }
}
