# Frago — Local SOCKS5 + standalone TCP Fragment prototype

This Android source does not bundle or execute Xray or sing-box. When the VPN switch is enabled, Frago starts a local SOCKS5 CONNECT listener at **127.0.0.1:10808**. The bundled tun2socks component forwards the app's VPN TCP connections into that SOCKS5 listener. The Java bridge then applies best-effort write splitting to the first TLS ClientHello record.

JSON import is optional. Without JSON, the default Fragment settings are `packets=tlshello`, `length=10-400`, and `interval=1-30`. If a JSON profile is imported, only the Fragment length/interval and the existing direct-routing exceptions are read; the SOCKS port remains fixed at 10808.

**Limitations:** TCP CONNECT only; SOCKS5 UDP ASSOCIATE, UDP, QUIC/HTTP3 and DoH are not implemented. Splitting Java socket writes does not guarantee distinct TCP segments because Android/Linux may coalesce writes. This is a prototype, not a protocol-complete Xray replacement. Native binaries are ARM64 only.
