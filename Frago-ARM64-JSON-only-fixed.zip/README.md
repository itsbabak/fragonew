# Frago — JSON-only ARM64 Android VPN

Frago is a minimal Android VPN client that accepts **complete Xray JSON configurations only**. This build removes the separate proxy-profile and share-link import screens. The Xray core remains the configuration engine.

## Main screen

- Import a `.json` file using Android's document picker.
- View and edit the saved JSON directly in the app.
- Connect or disconnect the VPN with one switch.
- Optionally select installed apps for Android per-app VPN routing.

The package ID remains `net.typeblog.socks`, the app label is `Frago`, and the launcher artwork is unchanged. The build targets `arm64-v8a` only.

## JSON requirements and handling

The configuration must contain an Xray `inbounds` array with at least one `socks` inbound and a valid local port. Frago normalizes that inbound to listen on `127.0.0.1`, disables inbound credentials for the private app-to-core bridge, and enables SOCKS UDP on that local inbound. If the JSON includes a `dns` object, Frago adds a private loopback DNS inbound and a DNS outbound/routing rule so its existing DNS bridge can send DNS queries into Xray's DNS module. The rest of the imported configuration is retained by the JSON normalizer.

The tunnel uses the included `tun2socks` and `pdnsd` native bridges with the ARM64 Xray executable. This is not a replacement Xray implementation: it is a compact UI and Android wrapper around the Xray core. General UDP/QUIC behavior depends on the capabilities of the SOCKS/tun2socks bridge and should be tested with the actual configuration and apps.

## Build

The project is configured for `arm64-v8a`, Android API 24+, and a Release build with R8 and resource shrinking. The GitHub Actions workflow used by the repository should:

1. Extract this source ZIP.
2. Set up Java 17 before installing Android command-line tools and accepting SDK licenses.
3. Install Android platform 31 and build-tools 31.0.0.
4. Set up Java 11 for the legacy Gradle 7.2 wrapper.
5. Download the pinned official Xray Android ARM64 release, verify its SHA-256, strip ELF debug sections, and place it at `app/src/main/jniLibs/arm64-v8a/libxray.so`.
6. Run `./gradlew --no-daemon clean assembleDebug assembleRelease`.

The Xray core is distributed by [XTLS/Xray-core](https://github.com/XTLS/Xray-core) under its upstream license. The APK is larger than a client without Xray because the core itself is included; ARM64-only packaging, removal of legacy UI/code paths, R8, and resource shrinking avoid shipping unnecessary components.

## Validation status

The source changes are prepared, but a full Android build could not be run in this environment because Gradle distribution downloads and Android SDK downloads are unavailable here. Run the GitHub Actions build and test import, connect/disconnect, DNS, routing, and per-app selection on a real ARM64 Android device before relying on the APK.
