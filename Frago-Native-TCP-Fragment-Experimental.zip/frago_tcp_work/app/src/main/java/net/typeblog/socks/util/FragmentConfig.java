package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;

/** Reads the existing JSON profile and validates the local SOCKS port plus Fragment ranges. */
public final class FragmentConfig {
    public final int socksPort, minLength, maxLength, minInterval, maxInterval;
    private FragmentConfig(int p, int a, int b, int c, int d) {
        socksPort=p; minLength=a; maxLength=b; minInterval=c; maxInterval=d;
    }
    public static FragmentConfig parse(String raw) throws Exception {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("فایل JSON خالی است");
        JSONObject root = new JSONObject(raw);
        JSONArray ins = root.optJSONArray("inbounds");
        if (ins == null || ins.length() == 0) throw new IllegalArgumentException("بخش inbounds در JSON پیدا نشد");
        int port = 10808;
        for (int i=0;i<ins.length();i++) {
            JSONObject in=ins.optJSONObject(i);
            if (in != null && "socks".equalsIgnoreCase(in.optString("protocol"))) {
                int candidate=in.optInt("port",10808); if(candidate>0 && candidate<65536) port=candidate; break;
            }
        }
        int min=10,max=400,imin=1,imax=30;
        JSONArray outs=root.optJSONArray("outbounds");
        if(outs!=null) for(int i=0;i<outs.length();i++) {
            JSONObject ob=outs.optJSONObject(i); if(ob==null) continue;
            JSONObject settings=ob.optJSONObject("settings"); if(settings==null) continue;
            JSONObject fragment=settings.optJSONObject("fragment"); if(fragment==null) fragment=ob.optJSONObject("fragment");
            if(fragment==null) continue;
            min=fragment.optInt("minLength",fragment.optInt("lengthMin",10));
            max=fragment.optInt("maxLength",fragment.optInt("lengthMax",400));
            imin=fragment.optInt("minInterval",fragment.optInt("intervalMin",1));
            imax=fragment.optInt("maxInterval",fragment.optInt("intervalMax",30));
            break;
        }
        min=Math.max(1,Math.min(min,4096)); max=Math.max(min,Math.min(max,8192));
        imin=Math.max(0,Math.min(imin,1000)); imax=Math.max(imin,Math.min(imax,2000));
        return new FragmentConfig(port,min,max,imin,imax);
    }
}
