package net.typeblog.socks;

import android.net.VpnService;
import android.util.Log;

import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** TCP-only local SOCKS5 bridge with best-effort TLS ClientHello write fragmentation. */
final class NativeFragmentSocksServer {
    private static final String TAG = "FragoNative";
    private final VpnService vpn;
    private final int port, minChunk, maxChunk, minDelay, maxDelay;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private ServerSocket listener;
    private Thread acceptThread;
    private final Random random = new Random();

    NativeFragmentSocksServer(VpnService vpn, int port, int minChunk, int maxChunk, int minDelay, int maxDelay) {
        this.vpn = vpn; this.port = port;
        this.minChunk = Math.max(1, minChunk); this.maxChunk = Math.max(this.minChunk, maxChunk);
        this.minDelay = Math.max(0, minDelay); this.maxDelay = Math.max(this.minDelay, maxDelay);
    }

    boolean start() {
        try {
            listener = new ServerSocket();
            listener.setReuseAddress(true);
            listener.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port));
            running.set(true);
            acceptThread = new Thread(() -> {
                while (running.get()) {
                    try { final Socket client = listener.accept(); workers.execute(() -> handle(client)); }
                    catch (SocketException e) { if (running.get()) Log.e(TAG, "SOCKS accept failed", e); }
                    catch (Exception e) { if (running.get()) Log.e(TAG, "SOCKS client failed", e); }
                }
            }, "Frago-SOCKS-Accept");
            acceptThread.start();
            return true;
        } catch (Exception e) { Log.e(TAG, "Cannot bind local SOCKS", e); stop(); return false; }
    }

    private void handle(Socket client) {
        Socket remote = null;
        try (Socket c = client) {
            c.setSoTimeout(15000);
            InputStream in = c.getInputStream(); OutputStream out = c.getOutputStream();
            int ver = in.read(), n = in.read();
            if (ver != 5 || n < 1) return;
            byte[] methods = readN(in, n); boolean noAuth = false;
            for (byte method : methods) if ((method & 255) == 0) noAuth = true;
            out.write(new byte[]{5, (byte)(noAuth ? 0 : 255)}); out.flush(); if (!noAuth) return;
            int v = in.read(), cmd = in.read(), reserved = in.read(), atyp = in.read();
            if (v != 5 || cmd != 1) { reply(out, 7); return; } // CONNECT only; UDP ASSOCIATE deliberately unsupported
            String host;
            if (atyp == 1) host = InetAddress.getByAddress(readN(in, 4)).getHostAddress();
            else if (atyp == 3) { int len = in.read(); if (len < 1) return; host = new String(readN(in, len), "UTF-8"); }
            else if (atyp == 4) host = InetAddress.getByAddress(readN(in, 16)).getHostAddress();
            else { reply(out, 8); return; }
            byte[] p = readN(in, 2); int dstPort = ((p[0]&255)<<8) | (p[1]&255);
            remote = new Socket(); vpn.protect(remote); remote.connect(new InetSocketAddress(host, dstPort), 12000);
            remote.setTcpNoDelay(true); remote.setSoTimeout(0); c.setSoTimeout(0);
            reply(out, 0);
            final Socket r = remote;
            workers.execute(() -> copyRemoteToClient(r, c));
            copyClientToRemote(in, remote.getOutputStream());
        } catch (Exception e) { Log.d(TAG, "SOCKS session ended: " + e.getMessage()); }
        finally { close(remote); }
    }

    private void copyClientToRemote(InputStream in, OutputStream out) throws Exception {
        byte[] first = readFirstTlsRecord(in);
        if (first != null) writeFragmented(out, first); // only first TLS record is fragmented
        byte[] buf = new byte[16 * 1024]; int n;
        while ((n = in.read(buf)) != -1) { out.write(buf, 0, n); out.flush(); }
    }

    private byte[] readFirstTlsRecord(InputStream in) throws Exception {
        int first = in.read(); if (first < 0) return null;
        byte[] header = new byte[5]; header[0] = (byte) first;
        readFully(in, header, 1, 4);
        int length = ((header[3]&255)<<8) | (header[4]&255);
        if ((header[0]&255) != 22 || (header[1]&255) != 3 || length < 1 || length > 18432) {
            // Not a recognizable TLS handshake record: preserve the consumed header.
            return header;
        }
        byte[] payload = new byte[length]; readFully(in, payload, 0, length);
        byte[] all = new byte[5 + length]; System.arraycopy(header,0,all,0,5); System.arraycopy(payload,0,all,5,length); return all;
    }

    private void writeFragmented(OutputStream out, byte[] data) throws Exception {
        // Only fragment a TLS ClientHello record (record type 22, handshake type 1).
        if (data.length < 6 || (data[0] & 255) != 22 || (data[5] & 255) != 1) {
            out.write(data); out.flush(); return;
        }
        int off = 0;
        while (off < data.length) {
            int size = minChunk + random.nextInt(Math.max(1, maxChunk - minChunk + 1));
            int n = Math.min(size, data.length - off);
            out.write(data, off, n); out.flush(); off += n;
            if (off < data.length && maxDelay > 0) Thread.sleep(minDelay + random.nextInt(Math.max(1, maxDelay - minDelay + 1)));
        }
    }

    private void copyRemoteToClient(Socket remote, Socket client) {
        try { InputStream in=remote.getInputStream(); OutputStream out=client.getOutputStream(); byte[] b=new byte[16*1024]; int n; while((n=in.read(b))!=-1){out.write(b,0,n);out.flush();} }
        catch (Exception ignored) { } finally { close(client); close(remote); }
    }
    private static byte[] readN(InputStream in, int n) throws Exception { byte[] b=new byte[n]; readFully(in,b,0,n); return b; }
    private static void readFully(InputStream in, byte[] b, int off, int len) throws Exception { while(len>0){int n=in.read(b,off,len); if(n<0) throw new EOFException(); off+=n; len-=n;} }
    private static void reply(OutputStream out, int code) throws Exception { out.write(new byte[]{5,(byte)code,0,1,0,0,0,0,0,0}); out.flush(); }
    private static void close(Socket s) { if(s!=null) try{s.close();}catch(Exception ignored){} }
    void stop() { running.set(false); closeListener(); workers.shutdownNow(); }
    private void closeListener() { if(listener!=null) try{listener.close();}catch(Exception ignored){} }
}
