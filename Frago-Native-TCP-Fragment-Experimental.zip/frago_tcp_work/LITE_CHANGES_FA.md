# تغییرات نسخه Native TCP Fragment

- حذف وابستگی اجرایی Xray و کلاس XrayConfig.
- حفظ Android VpnService و پل‌های Native موجود (tun2socks و pdnsd).
- افزودن SOCKS5 محلی با پشتیبانی TCP CONNECT.
- غیرفعال بودن UDP ASSOCIATE و سایر مسیرهای UDP.
- افزودن تقسیم best-effort اولین TLS handshake record با بازه chunk و delay قابل تنظیم.
- حفظ رابط کاربری انتخاب JSON و پروفایل‌ها؛ JSON دیگر توسط Xray اجرا نمی‌شود.

این نسخه آزمایشی است. تقسیم write در لایه برنامه تضمین نمی‌کند که TCP stack بسته‌ها را جدا نگه دارد. APK و اتصال نهایی هنوز روی دستگاه واقعی آزمایش نشده‌اند.
