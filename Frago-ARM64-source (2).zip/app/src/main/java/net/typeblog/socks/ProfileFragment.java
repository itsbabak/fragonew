package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static net.typeblog.socks.util.Constants.ROUTE_ALL;

/** Minimal JSON-only Frago interface. Xray remains the configuration engine. */
public class ProfileFragment extends Fragment {
    private static final int REQUEST_IMPORT_JSON = 2101;
    private static final int REQUEST_VPN_PERMISSION = 2102;
    private static final int MAX_JSON_BYTES = 1024 * 1024;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statePoll = new Runnable() {
        @Override public void run() {
            updateState();
            if (isResumed()) handler.postDelayed(this, 2500L);
        }
    };

    private ProfileManager manager;
    private Profile profile;
    private Switch vpnSwitch;
    private CheckBox perAppCheck;
    private TextView statusText;
    private TextView configText;
    private TextView appsText;
    private Button editButton;
    private IVpnService binder;
    private boolean bound;
    private boolean starting;
    private boolean stopping;
    private final Runnable connectTimeout = () -> {
        if (starting) resetSwitch("اتصال برقرار نشد؛ کانفیگ و گزارش Xray را بررسی کنید.");
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            binder = IVpnService.Stub.asInterface(service);
            updateState();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            binder = null;
            updateState();
        }
    };

    @Override
    public View onCreateView(android.view.LayoutInflater inflater, ViewGroup container, Bundle state) {
        manager = new ProfileManager(getActivity().getApplicationContext());
        profile = manager.getDefault();
        // This build exposes only the complete Xray JSON workflow.
        profile.setRoute(ROUTE_ALL);
        profile.setIsXrayMode(true);

        int pad = dp(20);
        LinearLayout root = new LinearLayout(getActivity());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF5F7FA);

        ScrollView scroll = new ScrollView(getActivity());
        scroll.setFillViewport(true);
        scroll.addView(root);

        TextView title = new TextView(getActivity());
        title.setText("Frago");
        title.setTextSize(28);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(0xFF172033);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(getActivity());
        subtitle.setText("اتصال امن با کانفیگ JSON");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF667085);
        root.addView(subtitle, matchWrap());
        setTop(subtitle, dp(4));

        statusText = new TextView(getActivity());
        statusText.setText("وضعیت: قطع");
        statusText.setTextSize(16);
        statusText.setTextColor(0xFF344054);
        statusText.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusText.setBackgroundColor(0xFFFFFFFF);
        root.addView(statusText, matchWrap());
        setTop(statusText, dp(24));

        vpnSwitch = new Switch(getActivity());
        vpnSwitch.setText("اتصال VPN");
        vpnSwitch.setTextSize(17);
        vpnSwitch.setTextColor(0xFF172033);
        vpnSwitch.setPadding(dp(4), dp(18), dp(4), dp(18));
        root.addView(vpnSwitch, matchWrap());
        setTop(vpnSwitch, dp(12));
        vpnSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked) startVpn(); else stopVpn();
        });

        Button importButton = makeButton("انتخاب فایل JSON");
        root.addView(importButton, matchWrap());
        setTop(importButton, dp(14));
        importButton.setOnClickListener(v -> openJsonPicker());

        editButton = makeButton("مشاهده و ویرایش JSON");
        root.addView(editButton, matchWrap());
        setTop(editButton, dp(8));
        editButton.setOnClickListener(v -> editJson());

        configText = new TextView(getActivity());
        configText.setTextSize(13);
        configText.setTextColor(0xFF667085);
        configText.setPadding(dp(4), dp(8), dp(4), dp(8));
        root.addView(configText, matchWrap());

        View divider = new View(getActivity());
        divider.setBackgroundColor(0xFFDDE2EA);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dividerParams.topMargin = dp(12);
        dividerParams.bottomMargin = dp(12);
        root.addView(divider, dividerParams);

        TextView appTitle = new TextView(getActivity());
        appTitle.setText("انتخاب برنامه‌ها");
        appTitle.setTextSize(16);
        appTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        appTitle.setTextColor(0xFF172033);
        root.addView(appTitle, matchWrap());

        perAppCheck = new CheckBox(getActivity());
        perAppCheck.setText("فقط برنامه‌های انتخاب‌شده از VPN استفاده کنند");
        perAppCheck.setTextSize(14);
        perAppCheck.setTextColor(0xFF344054);
        root.addView(perAppCheck, matchWrap());
        setTop(perAppCheck, dp(8));
        perAppCheck.setOnCheckedChangeListener((button, checked) -> {
            if (!checked) {
                profile.setIsPerApp(false);
                updateAppsText();
            } else if (TextUtils.isEmpty(profile.getAppList())) {
                showAppPicker();
            } else {
                profile.setIsPerApp(true);
                updateAppsText();
            }
        });

        Button chooseApps = makeButton("مدیریت برنامه‌های انتخابی");
        root.addView(chooseApps, matchWrap());
        setTop(chooseApps, dp(4));
        chooseApps.setOnClickListener(v -> showAppPicker());

        appsText = new TextView(getActivity());
        appsText.setTextSize(12);
        appsText.setTextColor(0xFF667085);
        appsText.setPadding(dp(4), dp(8), dp(4), dp(8));
        root.addView(appsText, matchWrap());

        TextView note = new TextView(getActivity());
        note.setText("برای شروع، فایل JSON کامل Xray را وارد کنید. تنظیمات DNS، مسیریابی و سایر قابلیت‌ها از خود کانفیگ خوانده می‌شوند.");
        note.setTextSize(12);
        note.setTextColor(0xFF667085);
        note.setPadding(dp(4), dp(18), dp(4), dp(4));
        root.addView(note, matchWrap());

        refreshConfigInfo();
        perAppCheck.setChecked(profile.isPerApp());
        updateAppsText();
        return scroll;
    }

    @Override public void onStart() {
        super.onStart();
        bindVpnService();
    }

    @Override public void onResume() {
        super.onResume();
        handler.removeCallbacks(statePoll);
        handler.post(statePoll);
    }

    @Override public void onPause() {
        handler.removeCallbacks(statePoll);
        super.onPause();
    }

    @Override public void onStop() {
        handler.removeCallbacks(statePoll);
        if (bound) {
            try { getActivity().unbindService(connection); } catch (Exception ignored) { }
            bound = false;
        }
        binder = null;
        super.onStop();
    }

    @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_JSON) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                importJson(data.getData());
            }
        } else if (requestCode == REQUEST_VPN_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) launchVpn();
            else resetSwitch("اجازه ایجاد VPN داده نشد");
        }
    }

    private void openJsonPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json", "text/json", "text/plain"});
        startActivityForResult(intent, REQUEST_IMPORT_JSON);
    }

    private void importJson(Uri uri) {
        InputStream in = null;
        try {
            in = getActivity().getContentResolver().openInputStream(uri);
            if (in == null) throw new IllegalArgumentException("فایل قابل خواندن نیست.");
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder raw = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                raw.append(line).append('\n');
                if (raw.length() > MAX_JSON_BYTES) throw new IllegalArgumentException("حجم JSON بیشتر از ۱ مگابایت است.");
            }
            saveJson(raw.toString());
        } catch (Exception e) {
            toast("خطا در واردکردن JSON: " + e.getMessage());
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { }
        }
    }

    private void editJson() {
        String current = profile.getXrayConfig();
        if (TextUtils.isEmpty(current)) {
            toast("ابتدا یک فایل JSON وارد کنید.");
            return;
        }
        final android.widget.EditText editor = new android.widget.EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(current);
        editor.setSelection(0);
        editor.setMinLines(12);
        editor.setMaxLines(22);
        int padding = dp(12);
        editor.setPadding(padding, padding, padding, padding);
        new AlertDialog.Builder(getActivity())
                .setTitle("ویرایش JSON")
                .setView(editor)
                .setPositiveButton("ذخیره", (dialog, which) -> saveJson(editor.getText().toString()))
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void saveJson(String raw) {
        try {
            XrayConfig.Prepared prepared = XrayConfig.prepare(raw);
            profile.setXrayConfig(prepared.json);
            profile.setXrayMode(true);
            refreshConfigInfo();
            toast("کانفیگ JSON ذخیره شد. برای اعمال تغییرات، VPN را یک‌بار قطع و وصل کنید.");
        } catch (Exception e) {
            toast("JSON معتبر نیست: " + e.getMessage());
        }
    }

    private void showAppPicker() {
        final PackageManager pm = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = pm.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(pm));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = profile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\n")) if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
        }
        for (ResolveInfo info : resolved) {
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            labels.add(info.loadLabel(pm) + "\n" + packageName);
        }
        if (packages.isEmpty()) {
            toast("برنامه‌ای برای نمایش پیدا نشد.");
            return;
        }
        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));

        new AlertDialog.Builder(getActivity())
                .setTitle("برنامه‌های مجاز")
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) if (checked[i]) {
                        if (list.length() > 0) list.append('\n');
                        list.append(packages.get(i));
                    }
                    if (list.length() == 0) {
                        profile.setIsPerApp(false);
                        perAppCheck.setChecked(false);
                        toast("حداقل یک برنامه را انتخاب کنید.");
                        return;
                    }
                    profile.setAppList(list.toString());
                    profile.setIsPerApp(true);
                    perAppCheck.setOnCheckedChangeListener(null);
                    perAppCheck.setChecked(true);
                    perAppCheck.setOnCheckedChangeListener((button, isChecked) -> {
                        if (!isChecked) {
                            profile.setIsPerApp(false);
                            updateAppsText();
                        } else if (TextUtils.isEmpty(profile.getAppList())) {
                            showAppPicker();
                        } else {
                            profile.setIsPerApp(true);
                            updateAppsText();
                        }
                    });
                    updateAppsText();
                    toast("فهرست برنامه‌ها ذخیره شد.");
                })
                .setNegativeButton("انصراف", (dialog, which) -> {
                    if (TextUtils.isEmpty(profile.getAppList())) {
                        perAppCheck.setOnCheckedChangeListener(null);
                        perAppCheck.setChecked(false);
                        perAppCheck.setOnCheckedChangeListener((button, isChecked) -> {
                            if (isChecked) showAppPicker();
                            else { profile.setIsPerApp(false); updateAppsText(); }
                        });
                    }
                })
                .show();
    }

    private void bindVpnService() {
        if (bound || getActivity() == null) return;
        bound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class), connection, 0);
    }

    private void startVpn() {
        if (TextUtils.isEmpty(profile.getXrayConfig())) {
            resetSwitch("ابتدا فایل JSON را وارد کنید");
            return;
        }
        starting = true;
        Intent permission = VpnService.prepare(getActivity());
        if (permission != null) startActivityForResult(permission, REQUEST_VPN_PERMISSION);
        else launchVpn();
    }

    private void launchVpn() {
        if (profile == null || TextUtils.isEmpty(profile.getXrayConfig())) {
            resetSwitch("کانفیگ JSON موجود نیست");
            return;
        }
        profile.setXrayMode(true);
        profile.setRoute(ROUTE_ALL);
        Utility.startVpn(getActivity(), profile);
        handler.removeCallbacks(connectTimeout);
        handler.postDelayed(connectTimeout, 60000L);
        bindVpnService();
        handler.removeCallbacks(statePoll);
        handler.post(statePoll);
    }

    private void stopVpn() {
        stopping = true;
        if (binder != null) {
            try { binder.stop(); } catch (Exception ignored) { }
        } else if (getActivity() != null) {
            getActivity().stopService(new Intent(getActivity(), SocksVpnService.class));
        }
        handler.postDelayed(statePoll, 500L);
    }

    private void updateState() {
        if (vpnSwitch == null || getActivity() == null) return;
        boolean running = false;
        if (binder != null) {
            try { running = binder.isRunning(); } catch (Exception ignored) { }
        }
        vpnSwitch.setOnCheckedChangeListener(null);
        vpnSwitch.setChecked(running || starting);
        vpnSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked) startVpn(); else stopVpn();
        });
        if (running) {
            handler.removeCallbacks(connectTimeout);
            starting = false;
            stopping = false;
            statusText.setText("وضعیت: متصل");
            statusText.setTextColor(0xFF16803C);
        } else if (starting) {
            statusText.setText("وضعیت: در حال اتصال…");
            statusText.setTextColor(0xFFB7791F);
        } else {
            stopping = false;
            statusText.setText("وضعیت: قطع");
            statusText.setTextColor(0xFF667085);
        }
        vpnSwitch.setEnabled(!starting || running);
    }

    private void resetSwitch(String message) {
        handler.removeCallbacks(connectTimeout);
        starting = false;
        stopping = false;
        if (vpnSwitch != null) {
            vpnSwitch.setOnCheckedChangeListener(null);
            vpnSwitch.setChecked(false);
            vpnSwitch.setOnCheckedChangeListener((button, checked) -> {
                if (checked) startVpn(); else stopVpn();
            });
        }
        if (statusText != null) statusText.setText("وضعیت: قطع");
        toast(message);
    }

    private void refreshConfigInfo() {
        if (configText == null || editButton == null) return;
        String json = profile.getXrayConfig();
        boolean ready = !TextUtils.isEmpty(json);
        configText.setText(ready ? "کانفیگ: آماده · " + json.length() + " نویسه" : "هنوز فایل JSON انتخاب نشده است.");
        editButton.setEnabled(ready);
        editButton.setAlpha(ready ? 1f : 0.5f);
    }

    private void updateAppsText() {
        if (appsText == null) return;
        String saved = profile.getAppList();
        int count = 0;
        if (!TextUtils.isEmpty(saved)) count = saved.split("\n").length;
        appsText.setText(profile.isPerApp()
                ? count + " برنامه انتخاب شده‌اند؛ فقط همین برنامه‌ها از VPN عبور می‌کنند."
                : "در حالت عادی، همه برنامه‌ها به‌جز خود Frago از VPN عبور می‌کنند.");
    }

    private Button makeButton(String label) {
        Button button = new Button(getActivity());
        button.setText(label);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void setTop(View view, int margin) {
        ViewGroup.LayoutParams old = view.getLayoutParams();
        LinearLayout.LayoutParams params;
        if (old instanceof LinearLayout.LayoutParams) params = (LinearLayout.LayoutParams) old;
        else params = matchWrap();
        params.topMargin = margin;
        view.setLayoutParams(params);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String message) {
        if (getActivity() != null) Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
    }
}
