# نمونه اولیه موتور مستقل TLS Fragment برای Frago

این پوشه یک **نمونه اولیه سطح پایین** است، نه APK آماده و نه جایگزین کامل Xray.

## چه چیزی پیاده‌سازی و تست شده؟
- تشخیص TLS Handshake record و پیام ClientHello کامل
- ارسال بایت‌های ClientHello در چند فراخوانی TCP با اندازه قطعه قابل تنظیم
- فعال‌کردن TCP_NODELAY و فاصله زمانی قابل تنظیم بین ارسال‌ها
- عبور بدون تغییر داده‌هایی که TLS ClientHello نیستند
- تست محلی با socketpair برای تشخیص، رد داده ناقص/غیر TLS و حفظ دقیق بایت‌ها

تست میزبان با `cc -O2 -Wall -Wextra -Werror -std=c11` اجرا شده و موفق بوده است.

## محدودیت‌های مهم
- این ماژول به‌تنهایی TUN، VPN Service، SOCKS، DNS-over-HTTPS، مسیریابی دامنه/IP یا UDP را پیاده‌سازی نمی‌کند.
- هنوز به `SocksVpnService` و `tun2socks` متصل نشده است.
- چند فراخوانی `send()` تضمین نمی‌کند کرنل و شبکه مرزها را به TCP segmentهای جداگانه تبدیل کنند؛ TCP ممکن است داده‌ها را تجمیع کند. سازگاری واقعی با رفتار Xray باید روی socket واقعی و شبکه آزمایش شود.
- بنابراین این نمونه، رفتار دقیق Xray `freedom.fragment` را تضمین نمی‌کند و نباید به‌عنوان جایگزین عملیاتی Xray نصب شود.
- کد فعلی Frago عمداً دست‌نخورده باقی مانده؛ `libxray.so` هنوز از مسیر اجرای اصلی حذف نشده است.

## اجرای تست میزبان
از پوشه `app/src/main/jni/fragment_engine_prototype`:

```sh
cc -O2 -Wall -Wextra -Werror -std=c11 frago_fragment_engine.c test_fragment_engine.c -o test_fragment_engine
./test_fragment_engine
```

خروجی مورد انتظار:

```text
PASS: TLS ClientHello detection, incomplete/non-TLS bypass, byte-preserving send
```

## مراحل لازم برای نسخه قابل نصب
1. ساخت TCP relay واقعی و اتصال ماژول به socket خروجی آن.
2. بافرکردن ClientHello کامل قبل از ارسال.
3. پیاده‌سازی DNS و routing مطابق JSON اصلی.
4. تعیین تکلیف UDP و مسیر TUN.
5. ساخت APK با Android SDK/NDK و تست اتصال، DNS، routing و Fragment روی دستگاه ARM64.
6. مقایسه مصرف CPU/RAM/باتری با نسخه Xray.
