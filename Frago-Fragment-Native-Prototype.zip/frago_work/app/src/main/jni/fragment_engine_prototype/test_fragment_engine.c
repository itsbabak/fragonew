#define _POSIX_C_SOURCE 200809L
#include "../native/frago_fragment_engine.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
    /* Minimal structurally valid TLS ClientHello record; payload bytes are test data. */
    uint8_t hello[] = {0x16,0x03,0x01,0x00,0x08, 0x01,0x00,0x00,0x04, 0xaa,0xbb,0xcc,0xdd};
    assert(frago_is_tls_client_hello(hello, sizeof(hello)) == 1);
    uint8_t not_hello[] = {0x17,0x03,0x03,0x00,0x04,1,2,3,4};
    assert(frago_is_tls_client_hello(not_hello, sizeof(not_hello)) == 0);
    uint8_t incomplete[] = {0x16,0x03,0x01,0x00,0x20,0x01,0,0,0};
    assert(frago_is_tls_client_hello(incomplete, sizeof(incomplete)) == 0);

    int sv[2]; assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0);
    uint32_t seed = 1234567;
    long sent = frago_fragment_send(sv[0], hello, sizeof(hello), 2, 4, 0, 0, &seed);
    assert(sent == (long)sizeof(hello));
    uint8_t received[sizeof(hello)]; size_t got = 0;
    while (got < sizeof(received)) { ssize_t r = read(sv[1], received + got, sizeof(received)-got); assert(r > 0); got += (size_t)r; }
    assert(memcmp(hello, received, sizeof(hello)) == 0);
    close(sv[0]); close(sv[1]);

    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0);
    seed = 42;
    sent = frago_fragment_send(sv[0], not_hello, sizeof(not_hello), 2, 4, 0, 0, &seed);
    assert(sent == (long)sizeof(not_hello));
    uint8_t recv2[sizeof(not_hello)]; got = 0;
    while (got < sizeof(recv2)) { ssize_t r = read(sv[1], recv2 + got, sizeof(recv2)-got); assert(r > 0); got += (size_t)r; }
    assert(memcmp(not_hello, recv2, sizeof(not_hello)) == 0);
    close(sv[0]); close(sv[1]);
    puts("PASS: TLS ClientHello detection, incomplete/non-TLS bypass, byte-preserving send");
    return 0;
}
