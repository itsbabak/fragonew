# Frago — Native TLS Fragment prototype (ARM64)

This is a source-only prototype build in which the Xray core and the previous SOCKS/TUN/DNS bridge stack have been removed. The Android screen is retained as a minimal Frago shell and the standalone native C Fragment primitive is included as an ARM64 CMake library.

## Current contents

- Android application shell (`net.typeblog.socks`) with a Fragment-only status screen.
- Native C module that recognizes a complete TLS ClientHello and provides a low-level TCP write-splitting primitive.
- Host-side unit test for TLS ClientHello detection, incomplete/non-TLS bypass, and byte preservation.
- ARM64-only native packaging configuration.

## Deliberate limitations

This is **not a working VPN APK**. The native primitive is not connected to Android `VpnService`, a TUN reader, a TCP relay, DNS, or routing. The Connect switch is intentionally disabled. It does not accept or execute the previous Xray JSON configuration. No claim is made that separate `send()` calls produce separate on-wire TCP segments or reproduce Xray's `freedom.fragment` behavior.

## Host test

From `app/src/main/jni/fragment_engine_prototype`:

```sh
cc -O2 -Wall -Wextra -Werror -std=c11 frago_fragment_engine.c test_fragment_engine.c -o test_fragment_engine
./test_fragment_engine
```

Expected output:

```text
PASS: TLS ClientHello detection, incomplete/non-TLS bypass, byte-preserving send
```

## Android build

Requires Android SDK platform 31, Android NDK with CMake support, and the Gradle wrapper distribution configured by this project. Build with:

```sh
./gradlew --no-daemon clean assembleDebug
```

Only `arm64-v8a` is packaged. A successful Android build does not mean VPN connectivity is implemented; this archive is a source prototype pending a real TCP/TUN/DNS integration and device testing.
