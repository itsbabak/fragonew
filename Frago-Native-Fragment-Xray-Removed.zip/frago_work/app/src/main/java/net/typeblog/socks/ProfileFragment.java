package net.typeblog.socks;

import android.app.Fragment;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** UI shell for the standalone native TLS Fragment prototype. */
public class ProfileFragment extends Fragment {
    @Override
    public View onCreateView(android.view.LayoutInflater inflater, ViewGroup container, Bundle state) {
        int pad = dp(20);
        LinearLayout content = new LinearLayout(getActivity());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, pad, pad, pad);
        content.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(getActivity());
        title.setText("Frago");
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF172033);
        content.addView(title, matchWrap());

        TextView subtitle = new TextView(getActivity());
        subtitle.setText("موتور مستقل Native Fragment");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF667085);
        content.addView(subtitle, matchWrap());
        setTop(subtitle, dp(4));

        TextView status = new TextView(getActivity());
        status.setText("وضعیت: نمونه اولیه؛ اتصال VPN هنوز پیاده‌سازی نشده است");
        status.setTextSize(15);
        status.setTextColor(0xFF9A6700);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setBackgroundColor(0xFFFFFFFF);
        content.addView(status, matchWrap());
        setTop(status, dp(24));

        Switch vpnSwitch = new Switch(getActivity());
        vpnSwitch.setText("اتصال VPN");
        vpnSwitch.setTextSize(17);
        vpnSwitch.setTextColor(0xFF172033);
        vpnSwitch.setEnabled(false);
        vpnSwitch.setChecked(false);
        content.addView(vpnSwitch, matchWrap());
        setTop(vpnSwitch, dp(12));

        View divider = new View(getActivity());
        divider.setBackgroundColor(0xFFDDE2EA);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dividerParams.topMargin = dp(20);
        dividerParams.bottomMargin = dp(16);
        content.addView(divider, dividerParams);

        TextView heading = new TextView(getActivity());
        heading.setText("تنظیمات نمونه Fragment");
        heading.setTextSize(17);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(0xFF172033);
        content.addView(heading, matchWrap());

        addInfo(content, "نوع داده", "فقط TLS ClientHello");
        addInfo(content, "اندازه قطعه آزمایشی", "۱۰ تا ۴۰۰ بایت");
        addInfo(content, "فاصله آزمایشی", "۱ تا ۳۰ میلی‌ثانیه");
        addInfo(content, "معماری", "Native C · ARM64 target");

        TextView warning = new TextView(getActivity());
        warning.setText("این بسته فقط نمونه اولیه ماژول Fragment را نگه می‌دارد. ماژول هنوز به Android VPN Service، مسیر TCP و DNS متصل نیست؛ بنابراین کلید اتصال عمداً غیرفعال است و این نسخه ترافیک VPN عبور نمی‌دهد.");
        warning.setTextSize(13);
        warning.setTextColor(0xFF667085);
        warning.setPadding(dp(4), dp(22), dp(4), dp(4));
        content.addView(warning, matchWrap());

        ScrollView scroll = new ScrollView(getActivity());
        scroll.setFillViewport(true);
        scroll.addView(content);
        return scroll;
    }

    private void addInfo(LinearLayout parent, String label, String value) {
        TextView row = new TextView(getActivity());
        row.setText(label + "\n" + value);
        row.setTextSize(14);
        row.setTextColor(0xFF344054);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        row.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(8);
        parent.addView(row, params);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void setTop(View view, int margin) {
        ViewGroup.LayoutParams old = view.getLayoutParams();
        LinearLayout.LayoutParams params = old instanceof LinearLayout.LayoutParams
                ? (LinearLayout.LayoutParams) old : matchWrap();
        params.topMargin = margin;
        view.setLayoutParams(params);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
