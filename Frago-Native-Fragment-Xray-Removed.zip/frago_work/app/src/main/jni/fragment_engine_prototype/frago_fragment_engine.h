#ifndef FRAGO_FRAGMENT_ENGINE_H
#define FRAGO_FRAGMENT_ENGINE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Returns 1 only for a complete TLS record whose first handshake message is ClientHello. */
int frago_is_tls_client_hello(const uint8_t *data, size_t len);
/*
 * Send a TLS ClientHello buffer in TCP writes of chunk_min..chunk_max bytes.
 * TCP_NODELAY is enabled for the socket. Bytes are not modified. For non-ClientHello
 * input, the entire buffer is sent in one write sequence. Returns bytes sent, or -1.
 * This is a low-level fragment primitive, NOT a VPN/TUN/SOCKS engine.
 */
long frago_fragment_send(int fd, const uint8_t *data, size_t len,
                         unsigned chunk_min, unsigned chunk_max,
                         unsigned interval_min_ms, unsigned interval_max_ms,
                         uint32_t *seed);
#ifdef __cplusplus
}
#endif
#endif
