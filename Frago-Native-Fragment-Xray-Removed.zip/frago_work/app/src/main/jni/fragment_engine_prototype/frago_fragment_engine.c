#define _POSIX_C_SOURCE 200809L
#include "frago_fragment_engine.h"
#include <errno.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <time.h>

static uint32_t next_rand(uint32_t *s) {
    uint32_t x = (*s == 0) ? 0x9e3779b9u : *s;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    *s = x; return x;
}
static unsigned pick(uint32_t *s, unsigned lo, unsigned hi) {
    if (hi <= lo) return lo;
    return lo + (next_rand(s) % (hi - lo + 1));
}
int frago_is_tls_client_hello(const uint8_t *d, size_t n) {
    if (!d || n < 9) return 0;
    if (d[0] != 0x16 || d[1] != 0x03) return 0; /* TLS handshake record */
    size_t record_len = ((size_t)d[3] << 8) | d[4];
    if (record_len + 5 > n || record_len < 4) return 0;
    if (d[5] != 0x01) return 0; /* ClientHello handshake */
    size_t hello_len = ((size_t)d[6] << 16) | ((size_t)d[7] << 8) | d[8];
    return hello_len + 4 <= record_len;
}
static int send_all(int fd, const uint8_t *p, size_t n) {
    size_t off = 0;
    while (off < n) {
        ssize_t r = send(fd, p + off, n - off, MSG_NOSIGNAL);
        if (r < 0) { if (errno == EINTR) continue; return -1; }
        if (r == 0) { errno = EPIPE; return -1; }
        off += (size_t)r;
    }
    return 0;
}
static void pause_ms(unsigned ms) {
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    while (nanosleep(&ts, &ts) != 0 && errno == EINTR) {}
}
long frago_fragment_send(int fd, const uint8_t *data, size_t len,
                         unsigned cmin, unsigned cmax,
                         unsigned imin, unsigned imax, uint32_t *seed) {
    if (fd < 0 || (!data && len) || !seed || !len) { errno = EINVAL; return -1; }
    if (cmin == 0 || cmax < cmin || imax < imin) { errno = EINVAL; return -1; }
    int one = 1;
    (void)setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    if (!frago_is_tls_client_hello(data, len))
        return send_all(fd, data, len) == 0 ? (long)len : -1;
    size_t off = 0;
    while (off < len) {
        unsigned amount = pick(seed, cmin, cmax);
        size_t take = len - off < amount ? len - off : amount;
        if (send_all(fd, data + off, take) != 0) return -1;
        off += take;
        if (off < len && imax) pause_ms(pick(seed, imin, imax));
    }
    return (long)len;
}
