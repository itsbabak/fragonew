# Third-party notices

The Android application shell retains the upstream project license in `LICENSE`.

The native Fragment prototype in `app/src/main/jni/fragment_engine_prototype/` is original prototype code included in this archive. Review and add any required notices before redistributing a production build.
